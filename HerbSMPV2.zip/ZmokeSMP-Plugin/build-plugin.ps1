# Simple HerbSMP Maven Build Script
# Usage: .\build-plugin.ps1

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  HerbSMP v2.0.0 - Building Plugin JAR" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check if mvn is available
$mvnCmd = Get-Command mvn -ErrorAction SilentlyContinue
if (-not $mvnCmd) {
    Write-Host "ERROR: Maven (mvn) not found on PATH" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please:" -ForegroundColor Yellow
    Write-Host "1. Download Maven from https://maven.apache.org/download.cgi" -ForegroundColor White
    Write-Host "2. Extract to a folder (e.g., C:\Program Files\apache-maven-3.8.8)" -ForegroundColor White
    Write-Host "3. Run setup-maven-path.ps1 to add to PATH" -ForegroundColor White
    Write-Host "4. Close and reopen this terminal" -ForegroundColor White
    exit 1
}

Write-Host "Starting Maven build..." -ForegroundColor Green
Write-Host ""

# Build
cd $projectRoot
# Remove any old packaged JAR files before building
Get-ChildItem "$projectRoot\target\*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem "$projectRoot\*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
mvn clean package -DskipTests=true

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  BUILD SUCCESSFUL!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""

    $jarFile = Get-ChildItem "$projectRoot\target\HerbSMP-V2.0.0.jar" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($jarFile) {
        Copy-Item $jarFile.FullName "$projectRoot\HerbSMP-V2.0.0.jar" -Force
        Write-Host "JAR created: $($jarFile.Name)" -ForegroundColor Cyan
        Write-Host "Location: $($jarFile.DirectoryName)" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Next: Copy JAR to your Minecraft server's plugins/ folder and restart." -ForegroundColor Yellow
    }
} else {
    Write-Host "BUILD FAILED! Check errors above." -ForegroundColor Red
    exit 1
}
