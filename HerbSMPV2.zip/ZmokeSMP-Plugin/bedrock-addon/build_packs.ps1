$workspace = Resolve-Path (Join-Path $PSScriptRoot '..')
$packRoot = Join-Path $PSScriptRoot 'generated'
if (Test-Path $packRoot) { Remove-Item $packRoot -Recurse -Force }

$behaviorPackDir = Join-Path $packRoot 'behavior_pack'
$resourcePackDir = Join-Path $packRoot 'resource_pack'
New-Item -ItemType Directory -Path $behaviorPackDir/recipes,$resourcePackDir/textures/items,$resourcePackDir/texts -Force | Out-Null

$behaviorManifest = @{
  format_version = 2
  header = @{
    name = 'ZmokeSMP Seed Recipes'
    description = 'Adds Bedrock recipe-book recipes for the custom HerbSMP seeds when used through Geyser.'
    uuid = [guid]::NewGuid().ToString()
    version = @(1,0,0)
    min_engine_version = @(1,20,0)
  }
  modules = @(@{ type = 'data'; uuid = [guid]::NewGuid().ToString(); version = @(1,0,0) })
} | ConvertTo-Json -Depth 10
Set-Content -Path (Join-Path $behaviorPackDir 'manifest.json') -Value $behaviorManifest -Encoding utf8

$resourceManifest = @{
  format_version = 2
  header = @{
    name = 'ZmokeSMP Seed Recipes Resources'
    description = 'Resources for the HerbSMP seed recipes.'
    uuid = [guid]::NewGuid().ToString()
    version = @(1,0,0)
    min_engine_version = @(1,20,0)
  }
  modules = @(@{ type = 'resources'; uuid = [guid]::NewGuid().ToString(); version = @(1,0,0) })
} | ConvertTo-Json -Depth 10
Set-Content -Path (Join-Path $resourcePackDir 'manifest.json') -Value $resourceManifest -Encoding utf8

$recipes = @(
  @{ id = 'ak_47_herb_seed_recipe'; ingredients = @('minecraft:iron_ingot','minecraft:diamond','minecraft:iron_ingot','minecraft:iron_ingot','minecraft:wheat_seeds','minecraft:iron_ingot','minecraft:iron_ingot','minecraft:netherite_scrap','minecraft:iron_ingot') },
  @{ id = 'spaceman_herb_seed_recipe'; ingredients = @('minecraft:end_stone','minecraft:ender_eye','minecraft:ender_pearl','minecraft:end_stone','minecraft:wheat_seeds','minecraft:end_stone','minecraft:ender_pearl','minecraft:ender_eye','minecraft:end_stone') },
  @{ id = 'loud_lemon_herb_seed_recipe'; ingredients = @('minecraft:golden_apple','minecraft:golden_apple','minecraft:honeycomb','minecraft:honeycomb','minecraft:wheat_seeds','minecraft:honeycomb','minecraft:honeycomb','minecraft:golden_apple','minecraft:golden_apple') },
  @{ id = 'ogblaze_herb_seed_recipe'; ingredients = @('minecraft:blaze_powder','minecraft:blaze_powder','minecraft:blaze_powder','minecraft:blaze_rod','minecraft:wheat_seeds','minecraft:blaze_rod','minecraft:blaze_powder','minecraft:blaze_powder','minecraft:blaze_powder') },
  @{ id = 'pink_lemon_herb_seed_recipe'; ingredients = @('minecraft:pink_dye','minecraft:golden_apple','minecraft:honeycomb','minecraft:honeycomb','minecraft:wheat_seeds','minecraft:honeycomb','minecraft:honeycomb','minecraft:golden_apple','minecraft:pink_dye') },
  @{ id = 'blue_razz_herb_seed_recipe'; ingredients = @('minecraft:sweet_berries','minecraft:cyan_dye','minecraft:sweet_berries','minecraft:sweet_berries','minecraft:wheat_seeds','minecraft:sweet_berries','minecraft:sweet_berries','minecraft:blue_dye','minecraft:sweet_berries') }
)

$patternChars = @('a','b','c','d','e','f','g','h','i')
foreach ($recipe in $recipes) {
  $key = @{}
  for ($i = 0; $i -lt $recipe.ingredients.Count; $i++) {
    $key[$patternChars[$i]] = @{ item = $recipe.ingredients[$i] }
  }
  $json = @{
    format_version = '1.20.10'
    'minecraft:recipe_shaped' = @{
      description = @{ identifier = "zmokesmp:$($recipe.id)" }
      tags = @('crafting_table')
      pattern = @('abc','def','ghi')
      key = $key
      result = @{ item = 'minecraft:wheat_seeds'; count = 1 }
    }
  } | ConvertTo-Json -Depth 10
  Set-Content -Path (Join-Path $behaviorPackDir "recipes/$($recipe.id).json") -Value $json -Encoding utf8
}

$textureJson = @{
  resource_pack_name = 'herbsmp'
  texture_name = 'atlas.items'
  texture_data = @{
    wheat_seeds = @{ textures = 'textures/items/seed_icon' }
  }
} | ConvertTo-Json -Depth 10
Set-Content -Path (Join-Path $resourcePackDir 'textures/item_texture.json') -Value $textureJson -Encoding utf8

Set-Content -Path (Join-Path $resourcePackDir 'texts/en_US.lang') -Value 'item.minecraft:wheat_seeds=Herb Seeds' -Encoding utf8

$pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACklEQVR4nGMAAIAAeIhvAAAAAElFTkSuQmCC'
[System.IO.File]::WriteAllBytes((Join-Path $resourcePackDir 'textures/items/seed_icon.png'), [System.Convert]::FromBase64String($pngBase64))

Add-Type -AssemblyName System.IO.Compression.FileSystem
function New-McPackFromFolder([string]$sourceDir, [string]$outputPath) {
  if (Test-Path $outputPath) { Remove-Item $outputPath -Force }
  $tempZip = Join-Path $packRoot ([System.IO.Path]::GetRandomFileName() + '.zip')
  if (Test-Path $sourceDir) {
    if (Test-Path $tempZip) { Remove-Item $tempZip -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($sourceDir, $tempZip)
    Move-Item $tempZip $outputPath -Force
  }
}

New-McPackFromFolder -sourceDir $behaviorPackDir -outputPath (Join-Path $workspace 'HerbSMP-Bedrock-Behavior-V2.0.0.mcpack')
New-McPackFromFolder -sourceDir $resourcePackDir -outputPath (Join-Path $workspace 'HerbSMP-Bedrock-Resource-V2.0.0.mcpack')
