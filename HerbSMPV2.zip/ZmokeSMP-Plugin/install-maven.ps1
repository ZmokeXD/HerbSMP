# Automated Maven Installation Script
# Downloads Maven to your Downloads folder and sets up PATH

Write-Host "========================================"
Write-Host "  Maven Installation"
Write-Host "========================================"
Write-Host ""

$mavenFolder = "$env:USERPROFILE\Downloads\apache-maven-3.8.8"
$zipFile = "$env:USERPROFILE\Downloads\maven.zip"

# Step 1: Download
Write-Host "[1/3] Downloading Maven..."
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri "https://archive.apache.org/dist/maven/maven-3/3.8.8/binaries/apache-maven-3.8.8-bin.zip" -OutFile $zipFile
    Write-Host "[OK] Downloaded"
} catch {
    Write-Host "[ERROR] Download failed: $_"
    exit 1
}

# Step 2: Extract
Write-Host "[2/3] Extracting..."
try {
    Expand-Archive -Path $zipFile -DestinationPath "$env:USERPROFILE\Downloads" -Force
    Remove-Item $zipFile -Force
    Write-Host "[OK] Extracted to: $mavenFolder"
} catch {
    Write-Host "[ERROR] Extract failed: $_"
    exit 1
}

# Step 3: Setup PATH
Write-Host "[3/3] Setting up PATH..."
$mavenBin = "$mavenFolder\bin"
$env:Path = "$mavenBin;$env:Path"

# Verify
Write-Host ""
Write-Host "Testing Maven..."
& mvn -version

Write-Host ""
Write-Host "========================================"
Write-Host "  SUCCESS!"
Write-Host "========================================"
Write-Host "Maven is installed and ready."
Write-Host "Location: $mavenFolder"
Write-Host ""
Write-Host "To make this permanent, you need to set MAVEN_HOME:"
Write-Host "1. Right-click This PC or My Computer"
Write-Host "2. Select Properties > Advanced system settings"
Write-Host "3. Click Environment Variables"
Write-Host "4. Add user variable: MAVEN_HOME = $mavenFolder"
Write-Host "5. Edit PATH and add: %MAVEN_HOME%\bin"
Write-Host ""
Write-Host "For now, run your build with:"
Write-Host "  .\build.ps1"

