package com.zmokesmp.zmokesmps4;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.Map;

public class RankGUI {
    // Inventory constants
    private static final int INVENTORY_SIZE = 54;
    private static final String INVENTORY_TITLE = "§b§lZmoke SMP Rank Shop";
    
    // Border and layout constants
    private static final int[] TOP_ROW = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    private static final int[] BOTTOM_ROW = {45, 46, 47, 48, 49, 50, 51, 52, 53};
    private static final int[] CENTER_AREA = {10, 11, 12, 13, 14, 15, 16,
                                              19, 20, 21, 22, 23, 24, 25,
                                              28, 29, 30, 31, 32, 33, 34,
                                              37, 38, 39, 40, 41, 42, 43};
    
    private final Plugin plugin;
    private final Player player;

    public RankGUI(Plugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    public void open() {
        Inventory inv = Bukkit.createInventory(null, INVENTORY_SIZE, INVENTORY_TITLE);
        
        ItemStack redPane = createGlassPane();
        
        // Create border (all edges)
        for (int slot : TOP_ROW) {
            inv.setItem(slot, redPane);
        }
        for (int slot : BOTTOM_ROW) {
            inv.setItem(slot, redPane);
        }
        // Left column: 9, 18, 27, 36 (0 and 45 already set)
        inv.setItem(9, redPane);
        inv.setItem(18, redPane);
        inv.setItem(27, redPane);
        inv.setItem(36, redPane);
        // Right column: 17, 26, 35, 44 (8 and 53 already set)
        inv.setItem(17, redPane);
        inv.setItem(26, redPane);
        inv.setItem(35, redPane);
        inv.setItem(44, redPane);

        // Get current rank
        Integer currentRank = plugin.getPlayerRank(player);
        
        // Place rank items only in the center area
        final int[] slotIndex = {0};

        // Get ranks and sort by rank number
        Map<Integer, Rank> rankConfigs = plugin.getRankConfigs();
        // Sort rank numbers and iterate through them, skip rank 0 (default level)
        rankConfigs.keySet().stream()
                .sorted()
                .filter(rankNum -> rankNum > 0)  // Skip rank 0 - it's the starting default
                .forEach(rankNum -> {
                    if (slotIndex[0] >= CENTER_AREA.length) return;
                    
                    ItemStack rankItem = createRankItem(rankNum, currentRank);
                    if (rankItem != null) {
                        inv.setItem(CENTER_AREA[slotIndex[0]], rankItem);
                        slotIndex[0]++;
                    }
                });

        player.openInventory(inv);
    }

    private ItemStack createRankItem(int rankNum, Integer currentRank) {
        Map<Integer, Rank> rankConfigs = plugin.getRankConfigs();
        if (!rankConfigs.containsKey(rankNum)) return null;

        Rank rank = rankConfigs.get(rankNum);
        if (rank == null) return null;
        
        // Get crop bonus from config
        int cropBonus = 0;
        org.bukkit.configuration.ConfigurationSection rankSection = plugin.getConfig().getConfigurationSection("ranks." + rankNum);
        if (rankSection != null) {
            cropBonus = rankSection.getInt("crop-bonus", 0);
        }
        
        ItemStack item = new ItemStack(Material.NAME_TAG);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName("§e" + rank.getName());
            if (currentRank != null && currentRank == rankNum) {
            meta.setLore(Arrays.asList(
                    "§a✓ Current Rank",
                    "§7Sell Boost: §a+" + rank.getSellBoost() + "%",
                    "§7Drop Boost: §a" + rank.getDropBoost() + "x",
                    "§7Crop Bonus: §a+" + cropBonus + " Herb"
                ));
            } else if (currentRank != null && currentRank > rankNum) {
                meta.setLore(Arrays.asList(
                    "§c✗ Already Passed",
                    "§7Sell Boost: §a+" + rank.getSellBoost() + "%",
                    "§7Drop Boost: §a" + rank.getDropBoost() + "x",
                    "§7Crop Bonus: §a+" + cropBonus + " Herb"
                ));
            } else {
                meta.setLore(Arrays.asList(
                    "§eClick to Purchase",
                    "§fPrice: §6$" + plugin.formatCurrency(rank.getPrice()),
                    "§7Sell Boost: §a+" + (int) rank.getSellBoost() + "%",
                    "§7Drop Boost: §a" + rank.getDropBoost() + "x",
                    "§7Crop Bonus: §a+" + cropBonus + " Herb"
                ));
            }
            item.setItemMeta(meta);
        }

        return item;
    }

    private ItemStack createGlassPane() {
        ItemStack pane = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        return pane;
    }
}

