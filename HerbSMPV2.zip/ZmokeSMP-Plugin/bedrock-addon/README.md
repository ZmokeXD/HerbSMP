﻿# ZmokeSMP Bedrock Add-on

This add-on adds Bedrock recipes for the custom HerbSMP seed items.

## Import
1. Import the behavior pack file named HerbSMP-Bedrock-Behavior-V2.0.0.mcpack into Bedrock.
2. Import the resource pack file named HerbSMP-Bedrock-Resource-V2.0.0.mcpack into Bedrock.
3. Enable both packs in the world settings.
