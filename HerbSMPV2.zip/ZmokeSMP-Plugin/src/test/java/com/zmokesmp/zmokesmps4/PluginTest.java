package com.zmokesmp.zmokesmps4;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PluginTest {
    @Test
    public void fortuneToolOnlyAddsAnExtraSeedOnTheRareChance() {
        assertEquals(1, Plugin.calculateSeedDropCount(false, 0.0));
        assertEquals(1, Plugin.calculateSeedDropCount(false, 0.0008));
        assertEquals(2, Plugin.calculateSeedDropCount(true, 0.0008));
        assertEquals(2, Plugin.calculateSeedDropCount(true, 0.00079));
        assertEquals(1, Plugin.calculateSeedDropCount(true, 0.00081));
        assertEquals(1, Plugin.calculateSeedDropCount(true, 1.0));
    }

    @Test
    public void strainOrderMatchesRequestedDisplayOrder() {
        Strain[] actual = Strain.values();
        Strain[] expected = {
            Strain.AK_47_HERB,
            Strain.SPACEMAN_HERB,
            Strain.LOUD_LEMON_HERB,
            Strain.OGBLAZE_HERB,
            Strain.PINK_LEMON_HERB,
            Strain.BLUE_RAZZ_HERB,
            Strain.HERB
        };
        assertArrayEquals(expected, actual);
    }

    @Test
    public void seedRecipeKeysUseConsistentNamespacedKeys() {
        assertEquals("ak_47_herb_seed", Plugin.buildRecipeKey(Strain.AK_47_HERB));
        assertEquals("pink_lemon_herb_seed", Plugin.buildRecipeKey(Strain.PINK_LEMON_HERB));
        assertEquals("herb_seed", Plugin.buildRecipeKey(Strain.HERB));
    }
}
