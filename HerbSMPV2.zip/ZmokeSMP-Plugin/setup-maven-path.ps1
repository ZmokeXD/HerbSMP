# Set up Maven PATH permanently for Windows
# This script adds Maven to your user environment variables

Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║        Maven PATH Setup - Persistent Configuration        ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Option 1: Auto-detect Maven
Write-Host "Step 1: Locating Maven installation..." -ForegroundColor Yellow

$searchPaths = @(
    "C:\Program Files\apache-maven*",
    "C:\Program Files (x86)\apache-maven*",
    "C:\maven*",
    "C:\tools\maven*",
    "$env:USERPROFILE\tools\maven*",
    "$env:USERPROFILE\apache-maven*"
)

$mavenPath = $null
foreach ($pattern in $searchPaths) {
    $found = Get-Item $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) {
        $mavenPath = $found.FullName
        break
    }
}

if (-not $mavenPath) {
    Write-Host ""
    Write-Host "Maven not found. Please provide the path manually:" -ForegroundColor Yellow
    $mavenPath = Read-Host "Enter full Maven installation path (e.g., C:\Program Files\apache-maven-3.8.8)"
}

if (-not (Test-Path $mavenPath)) {
    Write-Host "✗ Path does not exist: $mavenPath" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Using Maven path: $mavenPath" -ForegroundColor Green
Write-Host ""

# Step 2: Set environment variables
Write-Host "Step 2: Setting environment variables..." -ForegroundColor Yellow

try {
    [Environment]::SetEnvironmentVariable('MAVEN_HOME', $mavenPath, 'User')
    Write-Host "✓ Set MAVEN_HOME = $mavenPath" -ForegroundColor Green
    
    $currentPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $mavenBin = Join-Path $mavenPath "bin"
    
    if ($currentPath -notlike "*$mavenBin*") {
        $newPath = "$currentPath;$mavenBin"
        [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
        Write-Host "✓ Added $mavenBin to PATH" -ForegroundColor Green
    } else {
        Write-Host "✓ Maven bin already in PATH" -ForegroundColor Green
    }
} catch {
    Write-Host "✗ Error setting environment variables: $_" -ForegroundColor Red
    Write-Host "You may need to run this script as Administrator." -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "Step 3: Verification" -ForegroundColor Yellow
Write-Host "⚠ Close all open PowerShell terminals and open a NEW terminal." -ForegroundColor Yellow
Write-Host "Then run: mvn -v" -ForegroundColor Gray
Write-Host ""
Write-Host "✓ Setup complete! Environment variables are now persistent." -ForegroundColor Green
