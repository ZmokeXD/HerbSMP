package com.zmokesmp.zmokesmps4;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Represents the different Herb strains used by the plugin.
 *
 * The enum provides a canonical key (used in configuration sections and
 * maps), optional crafting ingredients and utility helpers.  By centralizing
 * the values we avoid hard‑coded strings scattered across the codebase.
 */
public enum Strain {
    AK_47_HERB("ak-47-herb", new Material[]{
        Material.IRON_INGOT, Material.DIAMOND, Material.IRON_INGOT,
        Material.IRON_INGOT, Material.WHEAT_SEEDS, Material.IRON_INGOT,
        Material.IRON_INGOT, Material.NETHERITE_SCRAP, Material.IRON_INGOT
    }),
    SPACEMAN_HERB("spaceman-herb", new Material[]{
        Material.END_STONE, Material.ENDER_EYE, Material.ENDER_PEARL,
        Material.END_STONE, Material.WHEAT_SEEDS, Material.END_STONE,
        Material.ENDER_PEARL, Material.ENDER_EYE, Material.END_STONE
    }),
    LOUD_LEMON_HERB("loud-lemon-herb", new Material[]{
        Material.GOLDEN_APPLE, Material.GOLDEN_APPLE, Material.HONEYCOMB,
        Material.HONEYCOMB, Material.WHEAT_SEEDS, Material.HONEYCOMB,
        Material.HONEYCOMB, Material.GOLDEN_APPLE, Material.GOLDEN_APPLE
    }),
    OGBLAZE_HERB("ogblaze-herb", new Material[]{
        Material.BLAZE_POWDER, Material.BLAZE_POWDER, Material.BLAZE_POWDER,
        Material.BLAZE_ROD, Material.WHEAT_SEEDS, Material.BLAZE_ROD,
        Material.BLAZE_POWDER, Material.BLAZE_POWDER, Material.BLAZE_POWDER
    }),
    PINK_LEMON_HERB("pink-lemon-herb", new Material[]{
        Material.PINK_DYE, Material.GOLDEN_APPLE, Material.HONEYCOMB,
        Material.HONEYCOMB, Material.WHEAT_SEEDS, Material.HONEYCOMB,
        Material.HONEYCOMB, Material.GOLDEN_APPLE, Material.PINK_DYE
    }),
    BLUE_RAZZ_HERB("blue-razz-herb", new Material[]{
        Material.SWEET_BERRIES, Material.CYAN_DYE, Material.SWEET_BERRIES,
        Material.SWEET_BERRIES, Material.WHEAT_SEEDS, Material.SWEET_BERRIES,
        Material.SWEET_BERRIES, Material.BLUE_DYE, Material.SWEET_BERRIES
    }),
    HERB("herb", null);

    private final String key;
    private final List<Material> recipeIngredients;

    Strain(String key, Material[] ingredients) {
        this.key = key;
        this.recipeIngredients = ingredients == null ? Collections.emptyList() : Arrays.asList(ingredients);
    }

    public String getKey() {
        return key;
    }

    public List<Material> getRecipeIngredients() {
        return recipeIngredients;
    }

    /**
     * Lookup a strain by its configuration key (case insensitive).
     */
    public static Optional<Strain> fromKey(String key) {
        if (key == null) return Optional.empty();
        for (Strain s : values()) {
            if (s.key.equalsIgnoreCase(key)) {
                return Optional.of(s);
            }
        }
        return Optional.empty();
    }

    /**
     * Return a human-friendly name (capitalized, spaces instead of hyphen).
     * Example: "og-kush" -> "OG Kush".
     */
    public String getDisplayNameFromKey() {
        String[] parts = key.split("[-_]");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(part.substring(0, 1).toUpperCase()).append(part.substring(1));
        }
        return sb.toString();
    }
}

