package com.zmokesmp.zmokesmps4;

/**
 * Holds configuration values for a strain loaded from the plugin config.
 * This is intentionally a simple data holder with public fields for
 * easy construction and access; the class is package-private since it's
 * not needed outside the core implementation.
 */
class StrainConfig {
    final String name;
    final long matureTimeMs;  // Growth time in milliseconds
    final long deathTimeMs;   // Death time in milliseconds (after maturity)
    final long smeltTime;
    final double sellPrice;

    StrainConfig(String name, long matureTimeMs, long deathTimeMs, long smeltTime, double sellPrice) {
        this.name = name;
        this.matureTimeMs = matureTimeMs;
        this.deathTimeMs = deathTimeMs;
        this.smeltTime = smeltTime;
        this.sellPrice = sellPrice;
    }
}

