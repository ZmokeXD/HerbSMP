param(
    [string]$ProjectRoot = "${PSScriptRoot}"
)

# Bump version script for Greensmp plugin
# Usage: .\bump-version.ps1 -ProjectRoot 'C:\path\to\project'

function Parse-Version($v) {
    # expect format like: test-v-0.1.2
    if ($v -match '^(.*-v-)(\d+)\.(\d+)\.(\d+)$') {
        return @{prefix=$matches[1]; major=[int]$matches[2]; minor=[int]$matches[3]; patch=[int]$matches[4]}
    }
    return $null
}

function Format-Version($parts) {
    return "$($parts.prefix)$($parts.major).$($parts.minor).$($parts.patch)"
}

function Bump-One() {
    param($parts)
    $parts.patch += 1
    if ($parts.patch -ge 10) {
        $parts.patch = 0
        $parts.minor += 1
        if ($parts.minor -ge 10) {
            $parts.minor = 0
            $parts.major += 1
        }
    }
    return $parts
}

$pom = Join-Path $ProjectRoot 'pom.xml'
$pluginYml = Join-Path $ProjectRoot 'src\main\resources\plugin.yml'
$pluginJava = Join-Path $ProjectRoot 'src\main\java\com\zmokesmp\zmokesmps4\Plugin.java'

if (!(Test-Path $pom)) { Write-Error "pom.xml not found at $pom"; exit 1 }
if (!(Test-Path $pluginYml)) { Write-Error "plugin.yml not found at $pluginYml"; exit 1 }
if (!(Test-Path $pluginJava)) { Write-Error "Plugin.java not found at $pluginJava"; exit 1 }

$pomXml = Get-Content $pom -Raw
if ($pomXml -match '<version>([^<]+)</version>') {
    $current = $matches[1]
} else { Write-Error "Could not find <version> in pom.xml"; exit 1 }

$parts = Parse-Version $current
if ($parts -eq $null) { Write-Error "Version string '$current' not parseable"; exit 1 }

$newParts = Bump-One $parts
$newVersion = Format-Version $newParts

Write-Host "Bumping version: $current -> $newVersion"
$search = [regex]::Escape("<version>$current</version>")
$pomXml = [regex]::Replace($pomXml, $search, "<version>$newVersion</version>")
Set-Content -Path $pom -Value $pomXml -Encoding UTF8

# Update plugin.yml
$pluginText = Get-Content $pluginYml -Raw
if ($pluginText -match "version:\s*([\S]+)") { $old = $matches[1] } else { Write-Error "Could not find version in plugin.yml"; exit 1 }
$pluginText = $pluginText -replace ([regex]::Escape($old)), $newVersion
Set-Content -Path $pluginYml -Value $pluginText -Encoding UTF8

# Update Plugin.java log lines (any occurrences of the old version string)
$javaText = Get-Content $pluginJava -Raw
$javaText = $javaText -replace [regex]::Escape($current), $newVersion
Set-Content -Path $pluginJava -Value $javaText -Encoding UTF8

Write-Host "Updated pom.xml, plugin.yml, and Plugin.java to $newVersion"
return $newVersion
