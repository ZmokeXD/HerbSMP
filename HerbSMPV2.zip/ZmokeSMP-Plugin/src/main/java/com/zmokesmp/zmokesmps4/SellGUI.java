package com.zmokesmp.zmokesmps4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SellGUI {
    public static final String GUI_TITLE = "§b§lZmoke SMP Herb Shop";
    private static final int GUI_SIZE = 27;
    private static final String SPACE_NAME = " ";
    private static final int CENTER_START = 10;
    private static final int CENTER_END = 16;

    private final Player player;
    private final Plugin plugin;

    public SellGUI(Plugin plugin, Player player) {
        this.player = player;
        this.plugin = plugin;
    }

    public void open() {
        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, GUI_TITLE);
        fillBorder(inv);
        addHerbButtons(inv);
        player.openInventory(inv);
    }

    private void fillBorder(Inventory inv) {
        ItemStack border = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = border.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(SPACE_NAME);
            border.setItemMeta(meta);
        }

        // Fill all slots first
        for (int i = 0; i < GUI_SIZE; i++) {
            inv.setItem(i, border);
        }

        // Clear the middle area (row 2: slots 10-16)
        for (int i = CENTER_START; i <= CENTER_END; i++) {
            inv.setItem(i, null);
        }
    }

    private void addHerbButtons(Inventory inv) {
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int idx = 0;
        for (Strain strain : Strain.values()) {
            if (idx >= slots.length) break;
            inv.setItem(slots[idx], createHerbItem(strain));
            idx++;
        }
    }

    private ItemStack createHerbItem(Strain strain) {
        ItemStack item = new ItemStack(Material.DRIED_KELP);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String displayName = plugin.getDryHerbName(strain);
            meta.setDisplayName(displayName);

            List<String> lore = new ArrayList<>();
            lore.add("§7Each: §a$" + String.format("%.2f", plugin.getSellPrice(strain, player)));
            lore.add("§7Inventory: §a$" + String.format("%.2f", getInventoryValue(strain)));
            lore.add("§7Click to sell all");
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private double getInventoryValue(Strain strain) {
        if (player == null) return 0.0;
        String displayName = plugin.getDryHerbName(strain);
        int count = countMatchingDryHerb(displayName);
        return count * plugin.getSellPrice(strain, player);
    }

    private int countMatchingDryHerb(String displayName) {
        int count = 0;
        ItemStack[] contents = player.getInventory().getContents();
        for (ItemStack item : contents) {
            if (item == null || item.getAmount() == 0) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta != null && displayName != null && displayName.equals(meta.getDisplayName())) {
                count += item.getAmount();
            }
        }
        return count;
    }

    public static int sellDryHerb(Player player, String displayName) {
        return sellDryHerb(player, displayName, Integer.MAX_VALUE);
    }

    public static int sellDryHerb(Player player, String displayName, int maxAmount) {
        if (player == null || displayName == null) return 0;

        int removed = 0;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && removed < maxAmount; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getAmount() == 0) continue;

            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                String itemDisplayName = meta.getDisplayName();
                if (itemDisplayName != null && itemDisplayName.equals(displayName)) {
                    int toRemove = Math.min(item.getAmount(), maxAmount - removed);
                    removed += toRemove;
                    item.setAmount(item.getAmount() - toRemove);
                }
            }
        }

        return removed;
    }
}

