# Auto-setup Maven if missing, then build
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "========================================"
Write-Host "  HerbSMP Build System (v2.0.0)"
Write-Host "========================================"
Write-Host ""

# Try system Maven first
$mvnCmd = Get-Command mvn -ErrorAction SilentlyContinue
if (-not $mvnCmd) {
    Write-Host "[SEARCHING] Looking for Maven installation..."
    $locations = @(
        "C:\Program Files\apache-maven*",
        "C:\Program Files (x86)\apache-maven*",
        "C:\maven*",
        "C:\tools\maven*",
        "$env:USERPROFILE\tools\maven*",
        "$env:USERPROFILE\Downloads\apache-maven*"
    )
    
    $found = $false
    foreach ($pattern in $locations) {
        $item = Get-Item $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($item -and (Test-Path (Join-Path $item.FullName "bin\mvn.cmd"))) {
            $env:Path = "$(Join-Path $item.FullName 'bin');$env:Path"
            Write-Host "[SUCCESS] Found Maven at: $($item.FullName)"
            $found = $true
            break
        }
    }
    
    if (-not $found) {
        Write-Host "[ERROR] Maven not found! Download from https://maven.apache.org/download.cgi"
        exit 1
    }
}

Write-Host "[BUILDING] Starting Maven build..."
Write-Host ""

cd $projectRoot
# Remove any old packaged JAR files before building
Get-ChildItem "$projectRoot\target\*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem "$projectRoot\*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
& mvn clean package -DskipTests=true

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================"
    Write-Host "  BUILD SUCCESSFUL!"
    Write-Host "========================================"

    $jar = Get-ChildItem "$projectRoot\target\HerbSMP-V2.0.0.jar" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($jar) {
        Copy-Item $jar.FullName "$projectRoot\HerbSMP-V2.0.0.jar" -Force
        Write-Host "JAR: $($jar.Name)"
        Write-Host "Copy to your server's plugins/ folder"
    }
} else {
    Write-Host "[ERROR] Build failed!"
    exit 1
}
