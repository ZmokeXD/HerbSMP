package com.zmokesmp.zmokesmps4;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

public class SeedRecipeGUI {
    private final Player player;
    private final Plugin plugin;

    public SeedRecipeGUI(Player player, Plugin plugin) {
        this.player = player;
        this.plugin = plugin;
    }

    public void open() {
        // Use 27-slot inventory but render seeds in a centered, multi-column grid
        Inventory inv = Bukkit.createInventory(null, 27, "§b§lZmoke SMP Seed Recipes");

        ItemStack borderPane = createBorderPane();
        ItemStack fillerPane = createFillerPane();

        // Fill full border, leave an inner area for items
        for (int i = 0; i < 27; i++) {
            // Top row: keep slots 0..8 as border
            if (i < 9) {
                inv.setItem(i, borderPane);
                continue;
            }
            // Bottom row: border
            if (i >= 18) {
                inv.setItem(i, borderPane);
                continue;
            }
            // Left and right columns are border
            if (i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderPane);
                continue;
            }
            // Inner slots: filler by default
            inv.setItem(i, fillerPane);
        }

        // Slots to place seed icons (two centered rows of up to 7 each)
        int[] seedSlots = {10,11,12,13,14,15,16,19,20,21,22,23,24,25};
        int idx = 0;
        for (Strain s : Strain.values()) {
            if (idx >= seedSlots.length) break; // prevent overflow
            inv.setItem(seedSlots[idx], createSeedItem(plugin.getSeedName(s)));
            idx++;
        }

        player.openInventory(inv);
    }

    private ItemStack createSeedItem(String displayName) {
        ItemStack item = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(displayName);
            meta.setLore(Arrays.asList("§eClick to view recipe", "§7Click again to open the crafting layout"));
            item.setItemMeta(meta);
        }

        return item;
    }



    public void showRecipe(Strain strain) {
        if (strain == null) return;
        if (strain == Strain.HERB) {
            showRecipeGui(strain, "§b", Arrays.asList("§7Found by breaking §egrass", "§7or killing §emonsters"), null);
        } else if (strain == Strain.BLUE_RAZZ_HERB) {
            Material[] recipeGrid = new Material[]{
                Material.SWEET_BERRIES, Material.CYAN_DYE, Material.SWEET_BERRIES,
                Material.SWEET_BERRIES, Material.WHEAT_SEEDS, Material.SWEET_BERRIES,
                Material.SWEET_BERRIES, Material.BLUE_DYE, Material.SWEET_BERRIES
            };
            showRecipeGui(strain, "§f", Arrays.asList("§7Use dyes and sweet berries around the Herb Seeds result"), recipeGrid);
        } else if (strain == Strain.PINK_LEMON_HERB) {
            Material[] recipeGrid = new Material[]{
                Material.PINK_DYE, Material.GOLDEN_APPLE, Material.HONEYCOMB,
                Material.HONEYCOMB, Material.WHEAT_SEEDS, Material.HONEYCOMB,
                Material.HONEYCOMB, Material.GOLDEN_APPLE, Material.PINK_DYE
            };
            showRecipeGui(strain, "§f", Arrays.asList("§7Craft this recipe in a 3x3 grid to create Pink Lemon Herb Seeds"), recipeGrid);
        } else {
            showRecipeGui(strain, "§f", Arrays.asList("§7" + ingredientListFor(strain)), strain.getRecipeIngredients().toArray(new Material[0]));
        }
    }

    // utility to build text description from ingredient list
    private String ingredientListFor(Strain s) {
        StringBuilder sb = new StringBuilder();
        for (Material m : s.getRecipeIngredients()) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append(m.name().replace('_', ' '));
        }
        return sb.toString();
    }

    private void showRecipeGui(Strain strain, String colorCode, List<String> ingredients, Material[] ingredientMaterials) {
        Inventory inv = Bukkit.createInventory(null, 27, colorCode + plugin.getSeedName(strain) + " Recipe");

        ItemStack borderPane = createBorderPane();
        ItemStack fillerPane = createFillerPane();

        // Fill every slot with filler first, then override the recipe area and red border slots.
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, fillerPane);
        }

        int[] redSlots = {0, 1, 5, 6, 7, 8, 9, 10, 16, 17, 18, 19, 23, 24, 25};
        for (int slot : redSlots) {
            inv.setItem(slot, borderPane);
        }

        // For herb recipe, show info instead of crafting grid
        if (strain == Strain.HERB) {
            ItemStack info = new ItemStack(Material.PAPER);
            ItemMeta meta = info.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(plugin.getSeedName(strain));
                meta.setLore(ingredients);
                info.setItemMeta(meta);
            }
            inv.setItem(12, info);
        } else {
            // Left-shifted 3x3 recipe grid positions based on user slot map
            int[] gridSlots = {2, 3, 4, 11, 12, 13, 20, 21, 22};
            int instructionSlot = 14; // crafting table to the right of the middle row
            int resultSlot = 15; // seed result beside the crafting table

            for (int i = 0; i < gridSlots.length; i++) {
                if (ingredientMaterials != null && i < ingredientMaterials.length && ingredientMaterials[i] != null) {
                    String displayName = ingredientMaterials[i].name().replace('_', ' ');
                    if (ingredientMaterials[i] == Material.WHEAT_SEEDS) {
                        displayName = plugin.getSeedName(Strain.HERB);
                    }
                    inv.setItem(gridSlots[i], createCraftingItem(ingredientMaterials[i], displayName));
                } else {
                    inv.setItem(gridSlots[i], createFillerPane());
                }
            }

            ItemStack instruction = new ItemStack(Material.CRAFTING_TABLE);
            ItemMeta instructMeta = instruction.getItemMeta();
            if (instructMeta != null) {
                instructMeta.setDisplayName("§eCrafting Table (3x3)");
                if (ingredientMaterials != null && ingredientMaterials.length > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < ingredientMaterials.length && i < 9; i++) {
                        if (i > 0) sb.append(", ");
                        sb.append(ingredientMaterials[i].name().replace('_',' '));
                    }
                    instructMeta.setLore(Arrays.asList("§7Recipe:", "§f" + sb.toString()));
                } else {
                    instructMeta.setLore(ingredients);
                }
                instruction.setItemMeta(instructMeta);
            }
            inv.setItem(instructionSlot, instruction);
            inv.setItem(resultSlot, createSeedResultItem(plugin.getSeedName(strain)));
        }
        
        // Back button
        ItemStack backButton = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backButton.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§cBack");
            backButton.setItemMeta(backMeta);
        }
        inv.setItem(26, backButton);
        
        player.openInventory(inv);
    }

    // Small helpers for consistent pane styling
    private static ItemStack createBorderPane() {
        ItemStack pane = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        return pane;
    }

    private static ItemStack createFillerPane() {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        return pane;
    }

    private static ItemStack createCraftingItem(Material material, String displayName) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§a" + displayName);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static ItemStack createSeedResultItem(String displayName) {
        ItemStack item = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(displayName);
            item.setItemMeta(meta);
        }
        return item;
    }

}

