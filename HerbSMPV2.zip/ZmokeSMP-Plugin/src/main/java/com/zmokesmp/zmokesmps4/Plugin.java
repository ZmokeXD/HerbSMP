package com.zmokesmp.zmokesmps4;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.FurnaceSmeltEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.enchantments.Enchantment;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;

public class Plugin extends JavaPlugin implements Listener {

    private final Random random = new Random();
    private final ConcurrentHashMap<String, Strain> plantedCrops = new ConcurrentHashMap<>();  // blockKey -> strain
    private final ConcurrentHashMap<String, Long> cropPlantedTime = new ConcurrentHashMap<>();  // blockKey -> planted timestamp (milliseconds)
    private final ConcurrentHashMap<String, Long> cropDeathTime = new ConcurrentHashMap<>();  // blockKey -> death time (seconds since epoch)
    // map strains by enum rather than raw strings
    private final ConcurrentHashMap<Strain, StrainConfig> strainConfigs = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> playerRanks = new ConcurrentHashMap<>();  // UUID -> rank number
    private final ConcurrentHashMap<Integer, Rank> rankConfigs = new ConcurrentHashMap<>();  // rank number -> Rank
    // Temporary sell boosts keyed by player UUID
    private final ConcurrentHashMap<UUID, BoostEntry> temporarySellBoosts = new ConcurrentHashMap<>();
    private FileConfiguration itemsConfig;
    private FileConfiguration playerDataConfig;
    private File playerDataFile;
    private RankDisplayManager rankDisplayManager;
    private int particleTaskId = -1;  // Store particle emission task ID
    private int growthTaskId = -1;  // Store growth check task ID
    
    private String ecoGiveCommand;
    private String ecoTakeCommand;
    private net.milkbowl.vault.economy.Economy vaultEconomy;

    private static final double FORTUNE_EXTRA_SEED_CHANCE = 0.0008;

    private long checkInterval;
    private double grassDropChance;
    private double mobDropChance;
    private int minLightLevel;

    @Override
    public void onEnable() {
        handleConfigUpdate();
        loadConfig();
        loadPlayerData();
        rankDisplayManager = new RankDisplayManager(this);
        extractGUIConfigs();
        registerRecipes();
        registerFurnaceRecipes();
        discoverSeedRecipesForOnlinePlayers();
        startGrowthCheckTimer();
        startParticleEmissionTask();
        rankDisplayManager.startActionBarUpdateTask();
        Bukkit.getPluginManager().registerEvents(this, this);
        
        // Try to hook into Vault economy
        setupVaultEconomy();
        
        // Register command executor and tab completer
        if (getCommand("herb") != null) {
            getCommand("herb").setExecutor(this);
            getCommand("herb").setTabCompleter(this);
        }
        if (getCommand("rankup") != null) {
            getCommand("rankup").setExecutor(this);
            getCommand("rankup").setTabCompleter(this);
        }
        
        getLogger().info("ZmokeSMP " + getDescription().getVersion() + " enabled!");
    }

    // Small helper container for temporary boosts
    private static class BoostEntry {
        final double percent; // additional percent (e.g. 50 for +50%)
        final long expiresAtMs;

        BoostEntry(double percent, long expiresAtMs) {
            this.percent = percent;
            this.expiresAtMs = expiresAtMs;
        }

        boolean isExpired() {
            return System.currentTimeMillis() > expiresAtMs;
        }

        long getRemainingMs() {
            long remaining = expiresAtMs - System.currentTimeMillis();
            return Math.max(0, remaining);
        }
    }

    private void setupVaultEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            net.milkbowl.vault.economy.Economy economy = null;
            RegisteredServiceProvider<net.milkbowl.vault.economy.Economy> rsp = Bukkit.getServicesManager().getRegistration(net.milkbowl.vault.economy.Economy.class);
            if (rsp != null) {
                economy = rsp.getProvider();
                vaultEconomy = economy;
                getLogger().info("§aHooked into Vault Economy for balance verification!");
            } else {
                getLogger().warning("§cVault is installed but economy plugin not found. Using command-based economy.");
            }
        } else {
            getLogger().info("§7Vault not found. Using command-based economy commands. Make sure your economy commands are correct!");
        }
    }

    @Override
    public void onDisable() {
        // Save player data and cancel running tasks
        savePlayerData();
        if (rankDisplayManager != null) {
            rankDisplayManager.stopActionBarTask();
        }
        if (particleTaskId != -1) {
            Bukkit.getScheduler().cancelTask(particleTaskId);
        }
        if (growthTaskId != -1) {
            Bukkit.getScheduler().cancelTask(growthTaskId);
        }
        getLogger().info("ZmokeSMP " + getDescription().getVersion() + " disabled!");
    }

    private void loadPlayerData() {
        playerDataFile = new File(getDataFolder(), "player-data.yml");
        if (!playerDataFile.exists()) {
            try {
                playerDataFile.createNewFile();
            } catch (java.io.IOException e) {
                getLogger().warning("Failed to create player-data.yml: " + e.getMessage());
            }
        }
        playerDataConfig = YamlConfiguration.loadConfiguration(playerDataFile);
        
        // Load player ranks from separate file
        playerRanks.clear();
        org.bukkit.configuration.ConfigurationSection playersSection = playerDataConfig.getConfigurationSection("players");
        if (playersSection != null) {
            for (String uuidKey : playersSection.getKeys(false)) {
                try {
                    int rankNum = playerDataConfig.getInt("players." + uuidKey, 0);
                    playerRanks.put(uuidKey, rankNum);
                } catch (Exception e) {
                    getLogger().warning("§cError loading rank for player " + uuidKey + ": " + e.getMessage());
                }
            }
            getLogger().info("§aTotal loaded player ranks: " + playerRanks.size());
        } else {
            getLogger().info("§7No player data found in player-data.yml");
        }
    }
    
    private void savePlayerData() {
        if (playerDataConfig != null && playerDataFile != null) {
            try {
                // Update config with current rankData
                for (Map.Entry<String, Integer> entry : playerRanks.entrySet()) {
                    playerDataConfig.set("players." + entry.getKey(), entry.getValue());
                }
                playerDataConfig.save(playerDataFile);
                getLogger().info("§aPlayer data saved to player-data.yml");
            } catch (java.io.IOException e) {
                getLogger().warning("Failed to save player-data.yml: " + e.getMessage());
            }
        }
    }
    
    public void savePlayerRank(String uuid, int rank) {
        playerDataConfig.set("players." + uuid, rank);
        try {
            playerDataConfig.save(playerDataFile);
        } catch (java.io.IOException e) {
            getLogger().warning("Failed to save player rank: " + e.getMessage());
        }
    }
    
    private void extractGUIConfigs() {
        // Extract GUI and item configs so server operators can customize them
        saveResource("items-config.yml", false);
        saveResource("gui-sell.yml", false);
        
        // Load items config
        File itemsConfigFile = new File(getDataFolder(), "items-config.yml");
        itemsConfig = YamlConfiguration.loadConfiguration(itemsConfigFile);
        getLogger().info("§aItems configuration loaded!");
        getLogger().info("§aSell GUI configuration extracted to plugin folder!");
    }

    private void handleConfigUpdate() {
        String currentVersion = "v3.1";
        String configVersion = getConfig().getString("config-version", "old");
        
        if (!configVersion.equals(currentVersion)) {
            getLogger().info("§eConfig version mismatch detected. Updating config...");
            
            // Backup old config file
            java.io.File configFile = new java.io.File(getDataFolder(), "config.yml");
            if (configFile.exists()) {
                java.io.File backupFile = new java.io.File(getDataFolder(), "config-" + configVersion + ".yml.backup");
                configFile.renameTo(backupFile);
                getLogger().info("§aOld config backed up to: config-" + configVersion + ".yml.backup");
            }
            
            // Save new default config
            saveDefaultConfig();
            reloadConfig();
            
            getLogger().info("§aConfig updated to version " + currentVersion);
        }
        // Only save default config if it doesn't exist, don't overwrite existing config
        if (!new java.io.File(getDataFolder(), "config.yml").exists()) {
            saveDefaultConfig();
        }
    }

    private void loadConfig() {
        checkInterval = getConfig().getLong("growth.check-interval", 100);
        minLightLevel = getConfig().getInt("growth.min-light-level", 11);
        grassDropChance = getConfig().getDouble("drops.grass-drop-chance", 3) / 100.0;
        mobDropChance = getConfig().getDouble("drops.mob-drop-chance", 5) / 100.0;
        
        // Load economy commands
        ecoGiveCommand = getConfig().getString("economy.give-command", "eco give %player% %amount%");
        ecoTakeCommand = getConfig().getString("economy.take-command", "eco take %player% %amount%");

        strainConfigs.clear();
        org.bukkit.configuration.ConfigurationSection strainsSection = getConfig().getConfigurationSection("strains");
        if (strainsSection == null) {
            getLogger().warning("§cStrains configuration section not found!");
            return;
        }
        for (String strainKey : strainsSection.getKeys(false)) {
            // convert key to enum; unrecognized keys are logged and skipped
            java.util.Optional<Strain> optionalStrain = Strain.fromKey(strainKey);
            if (optionalStrain.isPresent()) {
                Strain strain = optionalStrain.get();
                String path = "strains." + strainKey + ".";
                double growthTimeMinutes = getConfig().getDouble(path + "growth-time-minutes", 160.0);
                long matureTimeMs = (long) (growthTimeMinutes * 60000L);  // Convert minutes to milliseconds
                double deathTimeMinutes = getConfig().getDouble(path + "death-time-minutes", 20.0);
                long deathTimeMs = (long) (deathTimeMinutes * 60000L);  // Convert minutes to milliseconds
                long smeltTicks = 200L;  // Fixed vanilla furnace cook time (10 seconds)

                StrainConfig config = new StrainConfig(
                        getConfig().getString(path + "name"),
                        matureTimeMs,
                        deathTimeMs,
                        smeltTicks,
                        getConfig().getDouble(path + "sell-price", 100.0)
                );
                strainConfigs.put(strain, config);
            } else {
                getLogger().warning("§cUnknown strain key in config: " + strainKey);
            }
        }

        // Load ranks
        rankConfigs.clear();
        org.bukkit.configuration.ConfigurationSection ranksSection = getConfig().getConfigurationSection("ranks");
        if (ranksSection != null) {
            for (String rankKey : ranksSection.getKeys(false)) {
                try {
                    int rankNum = Integer.parseInt(rankKey);
                    String path = "ranks." + rankKey + ".";
                    String name = getConfig().getString(path + "name", "placeholder" + rankNum);
                    double price = getConfig().getDouble(path + "price", 1000);
                    double sellBoost = getConfig().getDouble(path + "sell-boost", 0);
                    double dropBoost = getConfig().getDouble(path + "drop-boost", 1.0);
                    
                    Rank rank = new Rank(rankNum, name, price, sellBoost, dropBoost);
                    rankConfigs.put(rankNum, rank);
                } catch (NumberFormatException e) {
                    getLogger().warning("§cInvalid rank key: " + rankKey);
                }
            }
        }

        getLogger().info("§aHerb plugin configured:");
        for (Map.Entry<Strain, StrainConfig> entry : strainConfigs.entrySet()) {
            Strain strain = entry.getKey();
            StrainConfig cfg = entry.getValue();
            double growthMinutes = cfg.matureTimeMs / 60000.0;
            getLogger().info("§7  " + strain.getKey() + ": " + String.format("%.2f", growthMinutes) + " minutes to mature, $" + cfg.sellPrice);
        }
        getLogger().info("§aLoaded " + rankConfigs.size() + " ranks");
        getLogger().info("§aMinimum light level for growth: " + minLightLevel + " (0-15)");
    }

    private void registerRecipes() {
        for (Strain strain : Strain.values()) {
            if (strain == Strain.HERB) continue; // "Herb" has no seed recipe
            List<Material> ingredients = strain.getRecipeIngredients();
            if (ingredients.size() == 9) {
                registerShapedRecipe(buildRecipeKey(strain), createSeed(strain), ingredients.toArray(new Material[0]));
            } else if (!ingredients.isEmpty()) {
                registerShapelessRecipe(buildRecipeKey(strain), createSeed(strain), ingredients.toArray(new Material[0]));
            }
        }
        getLogger().info("§aRegistered crafting recipes!");
    }

    public static String buildRecipeKey(Strain strain) {
        if (strain == null) {
            return "herb_seed";
        }
        String normalized = strain.getKey().toLowerCase(Locale.ROOT).replace('-', '_');
        return normalized + "_seed";
    }

    private void registerShapedRecipe(String key, ItemStack result, Material... ingredients) {
        if (ingredients.length != 9) return;
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(this, key), result);
        recipe.shape("123", "456", "789");
        recipe.setIngredient('1', ingredients[0]);
        recipe.setIngredient('2', ingredients[1]);
        recipe.setIngredient('3', ingredients[2]);
        recipe.setIngredient('4', ingredients[3]);
        recipe.setIngredient('5', ingredients[4]);
        recipe.setIngredient('6', ingredients[5]);
        recipe.setIngredient('7', ingredients[6]);
        recipe.setIngredient('8', ingredients[7]);
        recipe.setIngredient('9', ingredients[8]);
        Bukkit.addRecipe(recipe);
    }

    private void registerShapelessRecipe(String key, ItemStack result, Material... ingredients) {
        ShapelessRecipe recipe = new ShapelessRecipe(new NamespacedKey(this, key), result);
        for (Material ingredient : ingredients) {
            recipe.addIngredient(ingredient);
        }
        Bukkit.addRecipe(recipe);
    }

    private void discoverSeedRecipesForOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            discoverSeedRecipes(player);
        }
    }

    private void discoverSeedRecipes(Player player) {
        if (player == null) return;
        for (Strain strain : Strain.values()) {
            if (strain == Strain.HERB) continue;
            player.discoverRecipe(new NamespacedKey(this, buildRecipeKey(strain)));
        }
    }

    private Strain getSeedRecipeStrain(String recipeKey) {
        if (recipeKey == null || !recipeKey.endsWith("_seed")) return null;
        String baseKey = recipeKey.substring(0, recipeKey.length() - 5).replace('_', '-');
        return Strain.fromKey(baseKey).orElse(null);
    }

    @EventHandler
    public void onPrepareItemCraft(PrepareItemCraftEvent event) {
        if (event.getRecipe() == null) return;
        NamespacedKey key = null;
        if (event.getRecipe() instanceof ShapedRecipe shapedRecipe) {
            key = shapedRecipe.getKey();
        } else if (event.getRecipe() instanceof ShapelessRecipe shapelessRecipe) {
            key = shapelessRecipe.getKey();
        }
        if (key == null || !key.getNamespace().equals(getName().toLowerCase(Locale.ROOT))) return;
        Strain strain = getSeedRecipeStrain(key.getKey());
        if (strain == null) return;
        event.getInventory().setResult(createSeed(strain));
    }

    private void registerFurnaceRecipes() {
        for (Map.Entry<Strain, StrainConfig> entry : strainConfigs.entrySet()) {
            Strain strain = entry.getKey();
            ItemStack dry = getDryHerb(strain);
            registerSingleFurnaceRecipe(strain, Material.WHEAT, dry);
        }
    }

    private void registerSingleFurnaceRecipe(Strain strain, Material inputMaterial, ItemStack output) {
        StrainConfig config = strainConfigs.get(strain);
        if (config == null) return;
        NamespacedKey key = new NamespacedKey(this, "smelt_" + strain.getKey() + "_herb");
        int cookTimeTicks = (int) config.smeltTime;
        FurnaceRecipe recipe = new FurnaceRecipe(key, output, inputMaterial, 1.0f, cookTimeTicks);
        Bukkit.addRecipe(recipe);
    }

    private void startGrowthCheckTimer() {
        growthTaskId = new BukkitRunnable() {
            @Override
            public void run() {
                long currentTimeMs = System.currentTimeMillis();
                long currentTimeSeconds = currentTimeMs / 1000L;

                for (Map.Entry<String, Strain> entry : new ArrayList<>(plantedCrops.entrySet())) {
                    String blockKey = entry.getKey();
                    Strain strain = entry.getValue();
                    StrainConfig config = strainConfigs.get(strain);
                    if (config == null) {
                        plantedCrops.remove(blockKey);
                        cropPlantedTime.remove(blockKey);
                        cropDeathTime.remove(blockKey);
                        continue;
                    }

                    Location cropLoc = parseBlockKey(blockKey);
                    if (cropLoc == null) {
                        plantedCrops.remove(blockKey);
                        cropPlantedTime.remove(blockKey);
                        cropDeathTime.remove(blockKey);
                        continue;
                    }

                    Block block = cropLoc.getBlock();
                    if (block.getType() != Material.WHEAT) {
                        plantedCrops.remove(blockKey);
                        cropPlantedTime.remove(blockKey);
                        cropDeathTime.remove(blockKey);
                        continue;
                    }

                    Long plantedTimeMs = cropPlantedTime.get(blockKey);
                    if (plantedTimeMs == null) {
                        plantedCrops.remove(blockKey);
                        cropDeathTime.remove(blockKey);
                        continue;
                    }

                    if (block.getLightLevel() < minLightLevel) {
                        continue;
                    }

                    long cropAgeMs = Math.max(0, currentTimeMs - plantedTimeMs);
                    int targetAge = 0;
                    if (config.matureTimeMs > 0) {
                        targetAge = (int) Math.floor((double) cropAgeMs * 7.0 / config.matureTimeMs);
                    }
                    targetAge = Math.max(0, Math.min(targetAge, 7));

                    org.bukkit.block.data.BlockData blockData = block.getBlockData();
                    if (blockData instanceof Ageable) {
                        Ageable ageable = (Ageable) blockData;
                        if (ageable.getAge() != targetAge) {
                            ageable.setAge(targetAge);
                            block.setBlockData(ageable);
                        }
                    }
                }
            }
        }.runTaskTimer(this, 0L, 20L).getTaskId();
    }

    /**
     * Starts the particle emission task.
     * Emits bone meal particles for mature crops and redstone particles for dead crops.
     */
    private void startParticleEmissionTask() {
        particleTaskId = new BukkitRunnable() {
            @Override
            public void run() {
                long currentTimeSeconds = System.currentTimeMillis() / 1000;
                
                for (String blockKey : new ArrayList<>(plantedCrops.keySet())) {
                    Strain strain = plantedCrops.get(blockKey);
                    if (strain == null) continue;
                    
                    StrainConfig config = strainConfigs.get(strain);
                    if (config == null) continue;
                    
                    Long plantedTime = cropPlantedTime.get(blockKey);
                    if (plantedTime == null) continue;
                    
                    long currentTimeMs = System.currentTimeMillis();
                    long cropAgeMs = Math.max(0, currentTimeMs - plantedTime);
                    long matureAgeMs = config.matureTimeMs; // Already in milliseconds
                    
                    Location cropLoc = parseBlockKey(blockKey);
                    if (cropLoc == null) continue;
                    
                    Block block = cropLoc.getBlock();
                    if (!isHerbCrop(block)) continue;
                    
                    boolean isMature = cropAgeMs >= matureAgeMs;
                    Long deathTime = cropDeathTime.get(blockKey);
                    boolean isDead = deathTime != null && currentTimeSeconds >= deathTime;
                    
                    if (isDead) {
                        try {
                            cropLoc.getWorld().spawnParticle(Particle.DUST, cropLoc.clone().add(0.5, 0.5, 0.5), 5, 0.3, 0.3, 0.3, new Particle.DustOptions(Color.RED, 1.0f));
                        } catch (IllegalArgumentException ex) {
                            cropLoc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, cropLoc.clone().add(0.5, 0.5, 0.5), 5, 0.3, 0.3, 0.3, 0);
                        }
                    } else if (isMature) {
                        try {
                            cropLoc.getWorld().spawnParticle(Particle.valueOf("COMPOSTER"), cropLoc.clone().add(0.5, 0.5, 0.5), 5, 0.3, 0.3, 0.3, 0);
                        } catch (IllegalArgumentException e) {
                            cropLoc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, cropLoc.clone().add(0.5, 0.5, 0.5), 5, 0.3, 0.3, 0.3, 0);
                        }
                    }
                }
            }
        }.runTaskTimer(this, 20L, 20L).getTaskId(); // Run every 1 second (20 ticks), start after 1 second delay
    }

    /* -------------------- ITEM CONFIG HELPERS -------------------- */

    private String getConfigString(String path, String fallback) {
        if (itemsConfig == null) {
            return fallback;
        }
        String value = itemsConfig.getString(path);
        return value == null ? fallback : value;
    }

    public String getSeedName(Strain strain) {
        return getConfigString("items.seeds." + strain.getKey() + ".display-name", "§a" + strain.getDisplayNameFromKey() + " Seeds");
    }

    public String getSeedLore(Strain strain) {
        return getConfigString("items.seeds." + strain.getKey() + ".lore", "§7Plant on farmland");
    }

    public String getWetHerbName(Strain strain) {
        return getConfigString("items.wet-herb." + strain.getKey() + ".display-name", "§bWet " + strain.getDisplayNameFromKey());
    }

    public String getWetHerbLore(Strain strain) {
        return getConfigString("items.wet-herb." + strain.getKey() + ".lore", "§7Dry in furnace");
    }

    public String getDryHerbName(Strain strain) {
        return getConfigString("items.dry-herb." + strain.getKey() + ".display-name", "§aDry " + strain.getDisplayNameFromKey());
    }

    public String getDryHerbLorePrefix(Strain strain) {
        return getConfigString("items.dry-herb." + strain.getKey() + ".lore-prefix", "§7Sell for $");
    }

    /**
     * Parses a block key in format "world,x,y,z" into a Location object.
     * Returns null if the world doesn't exist or format is invalid.
     */
    private Location parseBlockKey(String blockKey) {
        try {
            String[] parts = blockKey.split(",");
            if (parts.length != 4) return null;
            
            String worldName = parts[0];
            int x = Integer.parseInt(parts[1]);
            int y = Integer.parseInt(parts[2]);
            int z = Integer.parseInt(parts[3]);
            
            org.bukkit.World world = Bukkit.getWorld(worldName);
            if (world == null) return null;
            
            return new Location(world, x, y, z);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Checks if a block is a HERB crop (mature crops are CROPS/CARROTS/POTATOES with age >= 7).
     * Also checks immature crops.
     */
    private boolean isHerbCrop(Block block) {
        if (block == null) return false;
        Material type = block.getType();
        
        // Check if it's a farmable crop block
        if (!(type == Material.CARROTS || type == Material.POTATOES || type == Material.WHEAT)) {
            return false;
        }
        
        // The block is a crop, it's been tracked in plantedCrops
        return true;
    }

    /* -------------------- ITEMS -------------------- */

    // helper that takes a Strain instead of repeating for each key
    private ItemStack createSeed(Strain strain) {
        return createSeed(getSeedName(strain), getSeedLore(strain));
    }

    private ItemStack createSeed(String displayName, String lore) {
        ItemStack item = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(displayName);
            meta.setLore(Arrays.asList(lore));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createWet(Strain strain, Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(getWetHerbName(strain));
            meta.setLore(Arrays.asList(getWetHerbLore(strain)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack getWetHerb(Strain strain) { return createWet(strain, Material.WHEAT); }

    private ItemStack getDryHerb(Strain strain) { return getStrainDryHerb(strain); }

    private ItemStack getStrainDryHerb(Strain strain) {
        String displayName = getDryHerbName(strain);
        String lorePrefix = getDryHerbLorePrefix(strain);

        StrainConfig config = strainConfigs.getOrDefault(strain, new StrainConfig("Herb", 0, 0, 0, 100.0));
        ItemStack item = new ItemStack(Material.DRIED_KELP);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(displayName);
            meta.setLore(Arrays.asList(lorePrefix + config.sellPrice));
            item.setItemMeta(meta);
        }
        return item;
    }

    /* -------------------- DROPS -------------------- */

    @EventHandler public void onPlayerJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        String uuid = player.getUniqueId().toString();
        // If player is new or not ranked, initialize to Level 0 (default rank)
        if (!playerRanks.containsKey(uuid)) {
            playerRanks.put(uuid, 0);
            // Save new player to data file immediately
            savePlayerRank(uuid, 0);
        }
        rankDisplayManager.initializePlayerScoreboard(player);
        Bukkit.getScheduler().runTaskLater(this, () -> discoverSeedRecipes(player), 2L);
    }

    @EventHandler
    public void onBonemealClick(PlayerInteractEvent e) {
        // Check if player right-clicked with bonemeal on a wheat block
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getItem() == null || e.getItem().getType() != Material.BONE_MEAL) return;
        
        Block clickedBlock = e.getClickedBlock();
        if (clickedBlock == null || clickedBlock.getType() != Material.WHEAT) return;
        
        String blockKey = clickedBlock.getWorld().getName() + "," + clickedBlock.getX() + "," + clickedBlock.getY() + "," + clickedBlock.getZ();
        Strain strain = plantedCrops.get(blockKey);
        
        if (strain == null) return;  // Not one of our crops
        
        e.setCancelled(true);
        
        Player player = e.getPlayer();
        Long deathTime = cropDeathTime.get(blockKey);
        long currentTimeSeconds = System.currentTimeMillis() / 1000;
        boolean isDead = deathTime != null && currentTimeSeconds >= deathTime;
        
        if (isDead) {
            // Crop is dead - 1% chance to cure
            if (random.nextDouble() <= 0.01) {
                // Success! Cure the dead crop
                Location cropLoc = clickedBlock.getLocation();
                try {
                    cropLoc.getWorld().spawnParticle(Particle.valueOf("COMPOSTER"), cropLoc.clone().add(0.5, 0.5, 0.5), 10, 0.3, 0.3, 0.3, 0);
                } catch (IllegalArgumentException ex) {
                    // Fallback for older versions
                    cropLoc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, cropLoc.clone().add(0.5, 0.5, 0.5), 10, 0.3, 0.3, 0.3, 0);
                }
                
                // Reset the planting time so the crop doesn't die immediately again
                long plantedTimeMs = System.currentTimeMillis();
                cropPlantedTime.put(blockKey, plantedTimeMs);
                cropDeathTime.remove(blockKey);
                
                // Consume bonemeal
                if (e.getItem().getAmount() > 1) {
                    e.getItem().setAmount(e.getItem().getAmount() - 1);
                } else {
                    player.getInventory().remove(e.getItem());
                }
                
                player.sendMessage("§a✔ Successfully cured the crop with bone meal!");
            } else {
                player.sendMessage("§c✗ Failed to cure the crop! Try again.");
            }
        } else {
            player.sendMessage("§c✗ This crop is still alive! No need to cure it.");
        }
    }

    @EventHandler
    public void onHerbCropGrow(org.bukkit.event.block.BlockGrowEvent e) {
        // Check light requirements for Herb crops
        Block block = e.getBlock();
        if (block.getType() != Material.WHEAT) return;
        
        String blockKey = block.getWorld().getName() + "," + block.getX() + "," + block.getY() + "," + block.getZ();
        if (!plantedCrops.containsKey(blockKey)) return;  // Only apply to our herb crops
        
        // Check light level at the crop location
        int lightLevel = block.getLocation().getBlock().getLightLevel();
        if (lightLevel < minLightLevel) {
            // Insufficient light - cancel growth
            e.setCancelled(true);
        }
    }

    @EventHandler public void onGrassBreak(BlockBreakEvent e) {
        if ((e.getBlock().getType() == Material.GRASS_BLOCK || e.getBlock().getType() == Material.TALL_GRASS)) {
            double chance = grassDropChance;
            // Apply rank drop boost
            Integer rank = playerRanks.get(e.getPlayer().getUniqueId().toString());
            if (rank != null) {
                Rank rankObj = rankConfigs.get(rank);
                if (rankObj != null) {
                    chance *= rankObj.getDropBoost();
                }
            }
            if (random.nextDouble() <= chance) {
                e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(), createSeed(Strain.HERB));
            }
        }
    }

    @EventHandler public void onMobDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Monster) {
            double chance = mobDropChance;
            // Apply rank drop boost if a player killed it
            if (e.getEntity().getKiller() != null) {
                Integer rank = playerRanks.get(e.getEntity().getKiller().getUniqueId().toString());
                if (rank != null) {
                    Rank rankObj = rankConfigs.get(rank);
                    if (rankObj != null) {
                        chance *= rankObj.getDropBoost();
                    }
                }
            }
            if (random.nextDouble() <= chance) {
                e.getEntity().getWorld().dropItemNaturally(e.getEntity().getLocation(), createSeed(Strain.HERB));
            }
        }
    }

    /* -------------------- PLANTING -------------------- */

    /**
     * Allow players to right-click a crop with a stick to check growth time
     */
    @EventHandler
    public void onCheckCropGrowth(PlayerInteractEvent e) {
        // Only handle right-click on block with a stick
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getItem() == null || e.getItem().getType() != Material.STICK) return;
        
        Block clickedBlock = e.getClickedBlock();
        if (clickedBlock == null || clickedBlock.getType() != Material.WHEAT) return;
        
        // Create block key to check if it's one of our crops
        String blockKey = clickedBlock.getWorld().getName() + "," + clickedBlock.getX() + "," + clickedBlock.getY() + "," + clickedBlock.getZ();
        Strain strain = plantedCrops.get(blockKey);
        
        if (strain == null) return;  // Not one of our special crops
        e.setCancelled(true);
        
        Player player = e.getPlayer();
        Long plantedTime = cropPlantedTime.get(blockKey);
        StrainConfig config = strainConfigs.get(strain);
        Long deathTime = cropDeathTime.get(blockKey);
        
        if (plantedTime == null || config == null) {
            player.sendMessage("§c✗ Error reading crop data!");
            return;
        }
        
        // Calculate growth progress
        long currentTimeMs = System.currentTimeMillis();
        long cropAgeMs = currentTimeMs - plantedTime;
        long matureAgeMs = config.matureTimeMs;  // Already in milliseconds
        
        // Check if dead
        long currentTimeSeconds = currentTimeMs / 1000;
        if (deathTime != null && currentTimeSeconds >= deathTime) {
            player.sendMessage("§6§l☠ Crop Status: DEAD");
            player.sendMessage("§7Use bone meal to cure the crop!");
            return;
        }
        
        // Check if mature
        if (cropAgeMs >= matureAgeMs) {
            player.sendMessage("§a✔ This crop is ready to harvest!");
            if (deathTime != null) {
                long secondsUntilDeath = deathTime - currentTimeSeconds;
                long minutesUntilDeath = (secondsUntilDeath + 59) / 60;  // Round up to nearest minute
                if (minutesUntilDeath > 0) {
                    player.sendMessage("§7Death in: §c" + minutesUntilDeath + " minute" + (minutesUntilDeath == 1 ? "" : "s"));
                } else {
                    player.sendMessage("§7Death in: §c< 1 minute");
                }
            }
            return;
        }
        
        // Calculate remaining time in minutes
        long remainingMs = matureAgeMs - cropAgeMs;
        long remainingMinutes = (remainingMs + 59999) / 60000;  // Round up to nearest minute
        
        // Send formatted message
        player.sendMessage("§6§l⏱ Growth Status");
        player.sendMessage("§7Strain: §e" + strain.getKey());
        player.sendMessage("§7Time remaining: §a" + remainingMinutes + " minute" + (remainingMinutes == 1 ? "" : "s"));
        
        // Show progress bar (rough calculation)
        int progressBars = (int) ((cropAgeMs * 10) / matureAgeMs);
        progressBars = Math.min(progressBars, 10);
        StringBuilder progressBar = new StringBuilder("§a");
        for (int i = 0; i < progressBars; i++) progressBar.append("█");
        progressBar.append("§7");
        for (int i = progressBars; i < 10; i++) progressBar.append("█");
        player.sendMessage("§7Progress: " + progressBar.toString() + " §7(" + (progressBars * 10) + "%)");
    }

    @EventHandler
    public void onPlant(PlayerInteractEvent e) {
        if (!(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK)) return;
        
        Strain strain = getSeedStrain(e.getItem());
        if (strain == null) return;

        Block block = e.getClickedBlock();
        if (block == null || block.getType() != Material.FARMLAND) return;

        Block crop = block.getRelative(0, 1, 0);
        if (crop.getType() != Material.AIR) return;

        crop.setType(Material.WHEAT);
        Ageable age = (Ageable) crop.getBlockData();
        age.setAge(0);
        crop.setBlockData(age);

        String blockKey = crop.getWorld().getName() + "," + crop.getX() + "," + crop.getY() + "," + crop.getZ();
        long plantedTimeMs = System.currentTimeMillis();
        plantedCrops.put(blockKey, strain);
        cropPlantedTime.put(blockKey, plantedTimeMs);
        
        StrainConfig config = strainConfigs.get(strain);
        if (config != null) {
            // Death time = maturation time + configured death-time (in milliseconds, convert to seconds)
            long maturitySeconds = config.matureTimeMs / 1000L;  // Convert ms to seconds
            long deathSeconds = config.deathTimeMs / 1000L;      // Convert ms to seconds
            long deathTimeSeconds = maturitySeconds + deathSeconds;
            cropDeathTime.put(blockKey, (plantedTimeMs / 1000) + deathTimeSeconds);
        }

        if (e.getItem() != null) e.getItem().setAmount(Math.max(0, e.getItem().getAmount() - 1));
        e.setCancelled(true);
    }

    private Strain getSeedStrain(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;

        String name = meta.getDisplayName();
        if (name == null) return null;

        for (Strain strain : strainConfigs.keySet()) {
            if (name.equals(getSeedName(strain))) {
                return strain;
            }
        }
        return null;
    }

    /* -------------------- HARVEST -------------------- */

    @EventHandler
    public void onHerbHarvest(BlockBreakEvent e) {
        if (e.getBlock().getType() != Material.WHEAT) return;

        String blockKey = e.getBlock().getWorld().getName() + "," + e.getBlock().getX() + "," + e.getBlock().getY() + "," + e.getBlock().getZ();
        Strain strain = plantedCrops.get(blockKey);

        if (strain == null) return;  // Not one of our crops

        // Check if crop is fully mature based on elapsed time vs strain maturation time
        Long plantedTime = cropPlantedTime.get(blockKey);
        StrainConfig config = strainConfigs.get(strain);
        if (plantedTime == null || config == null) {
            getLogger().warning("Harvest error: missing plant time or config for " + strain);
            // Clean up tracking data even on error
            plantedCrops.remove(blockKey);
            cropPlantedTime.remove(blockKey);
            cropDeathTime.remove(blockKey);
            return;
        }
        
        long elapsedMs = System.currentTimeMillis() - plantedTime;
        long matureTimeMs = config.matureTimeMs;  // Already in milliseconds
        
        // Check if crop is dead
        Long deathTime = cropDeathTime.get(blockKey);
        long currentTimeSeconds = System.currentTimeMillis() / 1000;
        boolean isDead = deathTime != null && currentTimeSeconds >= deathTime;
        
        if (isDead) {
            // Dead crop - no drops, remove tracking data since crop is being broken
            e.setDropItems(false);
            plantedCrops.remove(blockKey);
            cropPlantedTime.remove(blockKey);
            cropDeathTime.remove(blockKey);
            
            Player player = e.getPlayer();
            if (player != null) {
                player.sendMessage("§c✗ This crop is dead! Use bone meal to cure it before breaking.");
            }
            return;
        }
        
        if (elapsedMs < matureTimeMs) {
            // Immature crop - prevent harvest, player gets nothing as penalty for early harvest
            e.setDropItems(false);
            // Clean up tracking data
            plantedCrops.remove(blockKey);
            cropPlantedTime.remove(blockKey);
            cropDeathTime.remove(blockKey);
            
            Player player = e.getPlayer();
            if (player != null) {
                player.sendMessage("§c✗ This crop is not fully mature yet! Come back later.");
            }
            return;
        }

        // Fully mature - drop wet Herb and custom seed
        e.setDropItems(false);
        plantedCrops.remove(blockKey);
        cropPlantedTime.remove(blockKey);
        cropDeathTime.remove(blockKey);

        Player player = e.getPlayer();
        e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(), getWetHerbByStrain(strain));

        boolean usedFortuneTool = hasFortuneTool(player);
        int seedDrops = calculateSeedDropCount(usedFortuneTool, random.nextDouble());
        for (int i = 0; i < seedDrops; i++) {
            e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(), getSeedByStrain(strain));
        }
        
        // Add bonus crops based on rank
        int cropBonus = getCropBonus(player);
        for (int i = 0; i < cropBonus; i++) {
            e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(), getWetHerbByStrain(strain));
        }
    }

    private boolean hasFortuneTool(Player player) {
        if (player == null) return false;
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null) return false;

        Enchantment fortune = Enchantment.getByKey(NamespacedKey.minecraft("fortune"));
        return fortune != null && tool.getEnchantmentLevel(fortune) > 0;
    }

    static int calculateSeedDropCount(boolean usedFortuneTool, double randomValue) {
        if (!usedFortuneTool) return 1;
        return randomValue <= FORTUNE_EXTRA_SEED_CHANCE ? 2 : 1;
    }

    private ItemStack getWetHerbByStrain(Strain strain) {
        if (strain == null) {
            getLogger().warning("Unknown strain: null. Using default herb.");
            strain = Strain.HERB;
        }
        return getWetHerb(strain);
    }

    private ItemStack getSeedByStrain(Strain strain) {
        if (strain == null) {
            getLogger().warning("Unknown strain: null. Using default seed.");
            strain = Strain.HERB;
        }
        return createSeed(strain);
    }

    /* -------------------- FURNACE SMELTING -------------------- */

    @EventHandler
    public void onFurnaceSmelt(FurnaceSmeltEvent e) {
        if (e.getResult() != null && e.getResult().getType() == Material.DRIED_KELP) {
            ItemMeta conductorMeta = e.getSource().getItemMeta();
            if (conductorMeta != null) {
                String sourceName = conductorMeta.getDisplayName();
                if (sourceName != null) {
                    ItemStack resultItem = getStrainDryHerbByName(sourceName);
                    if (resultItem != null) {
                        // Preserve stack size to allow multiple items to smelt at once
                        resultItem.setAmount(e.getResult().getAmount());
                        e.setResult(resultItem);
                    }
                }
            }
        }
    }

    private ItemStack getStrainDryHerbByName(String wetHerbName) {
        // Try to match strain by checking all configured strains
        for (Strain strain : strainConfigs.keySet()) {
            if (wetHerbName.equals(getWetHerbName(strain))) {
                return getStrainDryHerb(strain);
            }
        }
        return null;
    }

    /* -------------------- GUI -------------------- */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }
        
        Player player = (Player) sender;
        
        // Handle /herb (no args shows help)
        if (args.length == 0) {
            showHerbCommands(player);
            return true;
        }
        
        String subcommand = args[0].toLowerCase();
        
        // Support top-level /rankup command along with /herb rankup
        if (command.getName().equalsIgnoreCase("rankup")) {
            new RankGUI(this, player).open();
            return true;
        }

        switch (subcommand) {
            case "sell":
                new SellGUI(this, player).open();
                return true;
            case "recipes":
                new SeedRecipeGUI(player, this).open();
                return true;
            case "rankup":
                new RankGUI(this, player).open();
                return true;
            case "boost":
                if (!player.isOp()) {
                    player.sendMessage("§cYou do not have permission for this command!");
                    return true;
                }
                // Usage: /herb boost <player> <amount> <duration> OR /herb boost <player> clear
                if (args.length < 3) {
                    player.sendMessage("§cUsage: /herb boost <player> <amount> <duration> (e.g. /herb boost Alice 50 30m) or /herb boost <player> clear");
                    return true;
                }
                String targetName = args[1];
                Player target = Bukkit.getPlayerExact(targetName);
                if (target == null) {
                    player.sendMessage("§cPlayer not found or not online: " + targetName);
                    return true;
                }

                if (args.length == 3 && args[2].equalsIgnoreCase("clear")) {
                    if (clearTemporarySellBoost(target)) {
                        player.sendMessage("§aCleared all temporary boosts for " + target.getName() + ".");
                        target.sendMessage("§cYour temporary sell boost has been removed.");
                    } else {
                        player.sendMessage("§eNo active temporary boost found for " + target.getName() + ".");
                    }
                    return true;
                }

                if (args.length < 4) {
                    player.sendMessage("§cUsage: /herb boost <player> <amount> <duration> (e.g. /herb boost Alice 50 30m) or /herb boost <player> clear");
                    return true;
                }
                String amountStr = args[2].replace("%", "");
                double percent;
                try {
                    percent = Double.parseDouble(amountStr);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cInvalid boost amount. Use one of: 50,100,150,200,250,300");
                    return true;
                }
                // Validate allowed amounts
                List<Double> allowed = Arrays.asList(50d,100d,150d,200d,250d,300d);
                if (!allowed.contains(percent)) {
                    player.sendMessage("§cInvalid boost amount. Allowed: 50,100,150,200,250,300");
                    return true;
                }
                long durationMs = parseDurationString(args[3]);
                if (durationMs <= 0) {
                    player.sendMessage("§cInvalid duration. Use formats like 30m, 1h, 45s");
                    return true;
                }
                applyTemporarySellBoost(player, target, percent, durationMs);
                return true;
            case "reload":
                if (!player.isOp()) {
                    player.sendMessage("§cYou do not have permission for this command!");
                    return true;
                }
                reloadHerbConfig(player);
                return true;
            case "clearranks":
                if (!player.isOp()) {
                    player.sendMessage("§cYou do not have permission for this command!");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cUsage: /herb clearranks <player>");
                    return true;
                }
                handleClearRanks(player, args[1]);
                return true;
            case "get":
                if (!player.isOp()) {
                    player.sendMessage("§cYou do not have permission for this command!");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cUsage: /herb get <item_name>");
                    return true;
                }
                handleGetItem(player, args[1].toLowerCase());
                return true;
            case "help":
            case "commands":
                showHerbCommands(player);
                return true;
            default:
                player.sendMessage("§cUnknown subcommand: " + subcommand);
                player.sendMessage("§eUse §a/herb help §efor a list of commands.");
                return true;
        }
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return Collections.emptyList();
        }
        
        // Only provide completions for /herb command
        if (!command.getName().equalsIgnoreCase("herb")) {
            return Collections.emptyList();
        }
        
        // If player is typing first argument (subcommand)
        if (args.length == 1) {
            List<String> completions = new ArrayList<>();
            String partial = args[0].toLowerCase();
            Player player = (Player) sender;
            
            // Add all subcommands
            List<String> allCommands = new ArrayList<>(Arrays.asList("sell", "recipes", "rankup", "help"));
            
            // Add OP-only commands if player is OP
            if (player.isOp()) {
                allCommands.add("reload");
                allCommands.add("clearranks");
                allCommands.add("get");
                allCommands.add("boost");
            }
            
            // Filter by partial match
            for (String sub : allCommands) {
                if (sub.startsWith(partial)) {
                    completions.add(sub);
                }
            }
            
            return completions;
        }
        
        // If player is typing clearranks or boost argument, provide player names
        if (args.length == 2 && (args[0].equalsIgnoreCase("clearranks") || args[0].equalsIgnoreCase("boost"))) {
            Player sender_player = (Player) sender;
            if (!sender_player.isOp()) {
                return Collections.emptyList();
            }
            
            List<String> playerNames = new ArrayList<>();
            String partial = args[1].toLowerCase();
            
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(partial)) {
                    playerNames.add(player.getName());
                }
            }
            
            return playerNames;
        }

        // Tab-complete for /herb boost amount or clear
        if (args.length == 3 && args[0].equalsIgnoreCase("boost")) {
            List<String> suggestions = new ArrayList<>();
            String partial = args[2].toLowerCase();
            for (String a : Arrays.asList("clear","50","100","150","200","250","300")) {
                if (a.startsWith(partial)) suggestions.add(a);
            }
            return suggestions;
        }

        // Tab-complete for /herb boost duration
        if (args.length == 4 && args[0].equalsIgnoreCase("boost")) {
            List<String> suggestions = Arrays.asList("30m","1h","15m","10m");
            List<String> out = new ArrayList<>();
            String partial = args[3].toLowerCase();
            for (String s : suggestions) if (s.startsWith(partial)) out.add(s);
            return out;
        }
        
        // If player is typing get argument, provide item names
        if (args.length == 2 && args[0].equalsIgnoreCase("get")) {
            Player sender_player = (Player) sender;
            if (!sender_player.isOp()) {
                return Collections.emptyList();
            }

            List<String> items = new ArrayList<>();
            for (Strain s : Strain.values()) {
                items.add(s.getKey() + "-seed");
                items.add(s.getKey() + "-wet");
                items.add(s.getKey() + "-dry");
            }

            List<String> completions = new ArrayList<>();
            String partial = args[1].toLowerCase();
            for (String item : items) {
                if (item.startsWith(partial)) {
                    completions.add(item);
                }
            }

            return completions;
        }
        
        return Collections.emptyList();
    }

    private void showHerbCommands(Player player) {
        player.sendMessage("\n§6========== §eá´¢á´á´á´‹á´‡sá´á´˜ Commands §6==========");
        player.sendMessage("§a/herb help§7 - Show this command list");
        player.sendMessage("§a/herb sell§7 - Open the herb selling GUI");
        player.sendMessage("§a/herb recipes§7 - View seed crafting recipes");
        player.sendMessage("§a/rankup§7 - Open the rank shop GUI");
        if (player.isOp()) {
            player.sendMessage("§c[OP] /herb reload§7 - Reload the plugin configuration");
            player.sendMessage("§c[OP] /herb boost <player> <amount> <duration>§7 - Give temporary sell boost (e.g. /herb boost Alice 50 30m)");
            player.sendMessage("§c[OP] /herb boost <player> clear§7 - Remove all active temporary boosts from a player");
            player.sendMessage("§c[OP] /herb clearranks <player>§7 - Reset a player's rank to 0");
            player.sendMessage("§c[OP] /herb get <item_name>§7 - Give yourself an item (tab-complete for items)");
        }
        player.sendMessage("§6========================================\n");
    }

    private void reloadHerbConfig(Player player) {
        reloadConfig();
        loadConfig();
        loadPlayerData();
        extractGUIConfigs();
        discoverSeedRecipesForOnlinePlayers();
        recalculateCropDeathTimes();  // Update death times for all planted crops based on new config
        player.sendMessage("§a✔ Config and player data reloaded!");
        getLogger().info("§aConfig and player data reloaded by " + player.getName());
    }

    private void recalculateCropDeathTimes() {
        // Recalculate death times for all currently planted crops based on new config values
        for (Map.Entry<String, Strain> entry : plantedCrops.entrySet()) {
            String blockKey = entry.getKey();
            Strain strain = entry.getValue();
            Long plantedTimeMs = cropPlantedTime.get(blockKey);
            
            if (plantedTimeMs == null) continue;
            
            StrainConfig config = strainConfigs.get(strain);
            if (config == null) continue;
            
            // Recalculate death time with new config values
            long maturitySeconds = config.matureTimeMs / 1000L;
            long deathSeconds = config.deathTimeMs / 1000L;
            long deathTimeSeconds = maturitySeconds + deathSeconds;
            long newDeathTime = (plantedTimeMs / 1000) + deathTimeSeconds;
            
            cropDeathTime.put(blockKey, newDeathTime);
        }
    }

    private void handleClearRanks(Player sender, String targetPlayerName) {
        Player targetPlayer = Bukkit.getPlayer(targetPlayerName);
        
        if (targetPlayer == null) {
            sender.sendMessage("§c✗ Player not found: " + targetPlayerName);
            return;
        }
        
        String uuid = targetPlayer.getUniqueId().toString();
        
        // Reset the rank in memory
        playerRanks.put(uuid, 0);
        
        // Save to player data file
        savePlayerRank(uuid, 0);
        
        // Send messages
        sender.sendMessage("§6┌──────────────────────────────────────────┐");
        sender.sendMessage("§a✔ Rank Reset Successfully!");
        sender.sendMessage("§7Player: §e" + targetPlayer.getName());
        sender.sendMessage("§7New Rank: §6Level 0");
        sender.sendMessage("§6└──────────────────────────────────────────┘");
        
        targetPlayer.sendMessage("§6┌──────────────────────────────────────────┐");
        targetPlayer.sendMessage("§c⚠ Your rank has been reset!");
        targetPlayer.sendMessage("§7Admin: §e" + sender.getName());
        targetPlayer.sendMessage("§7New Rank: §6Level 0");
        targetPlayer.sendMessage("§6└──────────────────────────────────────────┘");
        
        getLogger().info("§aRank reset for " + targetPlayer.getName() + " (" + uuid + ") by " + sender.getName());
    }

    private void handleGetItem(Player player, String itemName) {
        // itemName should be in the form "<strain>-seed|wet|dry".  strain may contain hyphens.
        Strain matched = null;
        String type = null;

        for (Strain s : Strain.values()) {
            for (String t : Arrays.asList("seed", "wet", "dry")) {
                String candidate = s.getKey() + "-" + t;
                if (candidate.equalsIgnoreCase(itemName)) {
                    matched = s;
                    type = t;
                    break;
                }
            }
            if (matched != null) break;
        }

        if (matched == null || type == null) {
            player.sendMessage("§c✗ Unknown item: " + itemName);
            player.sendMessage("§eValid items: ");
            for (Strain s : Strain.values()) {
                player.sendMessage("  " + s.getKey() + "-seed, " + s.getKey() + "-wet, " + s.getKey() + "-dry");
            }
            return;
        }

        ItemStack item;
        String displayName;
        switch (type) {
            case "seed":
                item = createSeed(matched);
                displayName = getSeedName(matched);
                break;
            case "wet":
                item = getWetHerb(matched);
                displayName = getWetHerbName(matched);
                break;
            case "dry":
                item = getDryHerb(matched);
                displayName = getDryHerbName(matched);
                break;
            default:
                // should not happen
                player.sendMessage("§c✗ Internal error building item");
                return;
        }

        if (item == null) {
            player.sendMessage("§c✗ Failed to create item!");
            return;
        }
        player.getInventory().addItem(item);
        player.sendMessage("§a✔ Given §e" + displayName);
        getLogger().info("§a" + player.getName() + " gave themselves " + displayName);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        String title = e.getView().getTitle();
        String lowerTitle = title == null ? "" : title.toLowerCase();
        
        // Handle individual recipe GUIs (detail view back button and click blocking)
        if (lowerTitle.endsWith(" recipe") && !lowerTitle.contains("seed recipes")) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            
            ItemMeta clickedMeta = clicked.getItemMeta();
            if (clickedMeta == null) return;
            String displayName = clickedMeta.getDisplayName();
            if (displayName == null) return;  // Safety check
            
            Player player = (Player) e.getWhoClicked();
            
            // Check for back button - use contains to handle color codes
            if (displayName.contains("Back")) {
                new SeedRecipeGUI(player, this).open();
                return;
            }
            return;  // Block all clicks in recipe detail view
        }
        
        // Handle seed recipe GUI overview
        if (lowerTitle.contains("seed recipes")) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.RED_STAINED_GLASS_PANE) return;

            Player player = (Player) e.getWhoClicked();
            ItemMeta clickedMeta = clicked.getItemMeta();
            if (clickedMeta == null) return;  // Safety check
            String displayName = clickedMeta.getDisplayName();
            if (displayName == null) return;  // Safety check
            
            SeedRecipeGUI gui = new SeedRecipeGUI(player, this);
            
            for (Strain s : Strain.values()) {
                if (displayName.equals(getSeedName(s))) {
                    gui.showRecipe(s);
                    break;
                }
            }
            return;
        }
        
        // Handle rank shop GUI
        if (lowerTitle.contains("rank") && lowerTitle.contains("shop")) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta() || clicked.getType() == Material.RED_STAINED_GLASS_PANE) return;

            Player player = (Player) e.getWhoClicked();
            ItemMeta clickedMeta = clicked.getItemMeta();
            if (clickedMeta == null) return;  // Safety check
            String displayName = clickedMeta.getDisplayName();
            if (displayName == null) return;  // Safety check
            
            // Find which rank was clicked using exact match with color code prefix
            Integer matchedRankNum = null;
            Rank matchedRank = null;
            
            for (Map.Entry<Integer, Rank> entry : rankConfigs.entrySet()) {
                // Create the expected display name format
                String expectedDisplayName = "§e" + entry.getValue().getName();
                if (displayName.equals(expectedDisplayName)) {
                    matchedRankNum = entry.getKey();
                    matchedRank = entry.getValue();
                    break;  // Found exact match, stop searching
                }
            }
            
            if (matchedRankNum == null) {
                    player.sendMessage("§c✗ Error: Unable to identify rank. Please report this!");
                return;
            }
            
            int rankNum = matchedRankNum;
            Integer currentRank = playerRanks.get(player.getUniqueId().toString());
            Rank rank = matchedRank;
            
            // Enforce sequential rank progression: can only buy the next rank
            if (currentRank == null) {
                player.sendMessage("§c✗ Error: Your rank data is missing!");
                player.closeInventory();
                return;
            }
            
            // Players can ONLY buy the next rank (currentRank + 1)
            if (rankNum != currentRank + 1) {
                player.sendMessage("§cYou must buy ranks in order! You need to purchase §aRank " + (currentRank + 1) + "§c first.");
                player.closeInventory();
                return;
            }
            
            // Attempt to take money from player
            double price = rank.getPrice();
            if (price > 0) {
                // First check if player has enough balance (if Vault is available)
                if (!hasPlayerEnoughMoney(player, price)) {
                    player.sendMessage("§6┌──────────────────────────────────────────┐");
                    player.sendMessage("§c✗ Payment Failed");
                    player.sendMessage("§7Rank: §e" + rank.getName());
                    player.sendMessage("§7Cost: §6$" + formatCurrency(price));
                    player.sendMessage("§7Status: §cInsufficient funds");
                    player.sendMessage("§6└──────────────────────────────────────────┘");
                    getLogger().warning(String.format("Rank purchase failed for %s: insufficient funds. Cost: $%.2f", player.getName(), price));
                    return;
                }
                
                // Player has enough money, attempt the transaction
                boolean success = takePlayerMoney(player, price);
                if (!success) {
                    player.sendMessage("§6┌──────────────────────────────────────────┐");
                    player.sendMessage("§c✗ Payment Failed");
                    player.sendMessage("§7Rank: §e" + rank.getName());
                    player.sendMessage("§7Cost: §6$" + formatCurrency(price));
                    player.sendMessage("§7Status: §cCommand error - contact admin");
                    player.sendMessage("§6└──────────────────────────────────────────┘");
                    getLogger().warning(String.format("Rank purchase failed for %s: command error. Cost: $%.2f. Make sure economy commands are correct!", player.getName(), price));
                    return;
                }
            }
            
            // Money taken successfully, grant the rank
            playerRanks.put(player.getUniqueId().toString(), rankNum);
            
            // Save rank to player data file
            savePlayerRank(player.getUniqueId().toString(), rankNum);
            
            // Update rank display
            rankDisplayManager.broadcastRankUp(player, rank);
            rankDisplayManager.updatePlayerRankDisplay(player, rank);
            
            player.sendMessage("§6┌──────────────────────────────────────────┐");
            player.sendMessage("§a✔ Rank Purchased Successfully!");
            player.sendMessage("§eRank: " + rank.getName());
            if (price > 0) {
                player.sendMessage("§7Payment: §6$" + formatCurrency(price));
            }
            player.sendMessage("§6└──────────────────────────────────────────┘");
            getLogger().info(String.format("%s purchased rank %d (%s) for $%.2f", player.getName(), rankNum, rank.getName(), price));
            // Keep GUI open - don't close it
        }

        // Handle new herb shop GUI
        if (title != null && title.equals(SellGUI.GUI_TITLE)) {
            if (e.getClickedInventory() != e.getView().getTopInventory()) {
                e.setCancelled(true);
                return;
            }
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            Player player = (Player) e.getWhoClicked();
            ItemMeta clickedMeta = clicked.getItemMeta();
            if (clickedMeta == null) return;  // Safety check
            String displayName = clickedMeta.getDisplayName();
            if (displayName == null) return;  // Safety check
            
            Strain strain = getStrainFromDisplayName(displayName);
            
            if (strain != null) {
                double totalProfit = sellAllDryHerb(player, strain);
                if (totalProfit > 0) {
                    // Give the player money
                    boolean success = givePlayerMoney(player, totalProfit);
                    if (success) {
                        player.sendMessage("§a✔ Sold Herb for §6$" + String.format("%.2f", totalProfit));
                    } else {
                        player.sendMessage("§c✗ Failed to process payment. Contact an admin.");
                    }
                }
            }
            player.closeInventory();
            return;
        }
    }

    private Strain getStrainFromDisplayName(String displayName) {
        if (displayName == null) return null;
        for (Strain strain : strainConfigs.keySet()) {
            if (displayName.equals(getDryHerbName(strain))) {
                return strain;
            }
        }
        return null;
    }

    private double sellAllDryHerb(Player player, Strain strain) {
        String displayName = getStrainDryHerbDisplayName(strain);
        int sold = SellGUI.sellDryHerb(player, displayName);
        return sold * getSellPrice(strain, player);
    }

    private String getStrainDryHerbDisplayName(Strain strain) {
        // Return the configured display name for the strain's dry Herb item
        String displayName = getDryHerbName(strain);
        if (displayName == null || displayName.isEmpty()) {
            getLogger().warning("No dry Herb name found for strain: " + strain + ". Using default.");
            return getDryHerbName(Strain.HERB);
        }
        return displayName;
    }

    double getSellPrice(Strain strain, Player player) {
        StrainConfig config = strainConfigs.get(strain);
        if (config == null) return 0;
        
        double price = config.sellPrice;
        // Apply rank sell boost
        Integer rank = playerRanks.get(player.getUniqueId().toString());
        if (rank != null && rankConfigs.containsKey(rank)) {
            double boost = rankConfigs.get(rank).getSellBoost();
            price *= (1 + boost / 100.0);
        }
        // Apply temporary boost if present
        double tempBoost = getTemporarySellBoostPercent(player.getUniqueId());
        if (tempBoost > 0) {
            price *= (1 + tempBoost / 100.0);
        }
        return price;
    }

    private BoostEntry getTemporarySellBoostEntry(UUID playerUuid) {
        BoostEntry entry = temporarySellBoosts.get(playerUuid);
        if (entry == null) return null;
        if (entry.isExpired()) {
            temporarySellBoosts.remove(playerUuid);
            return null;
        }
        return entry;
    }

    public double getTemporarySellBoostPercent(UUID playerUuid) {
        BoostEntry entry = getTemporarySellBoostEntry(playerUuid);
        if (entry == null) return 0;
        return entry.percent;
    }

    public String getTemporarySellBoostTimeLeft(UUID playerUuid) {
        BoostEntry entry = getTemporarySellBoostEntry(playerUuid);
        if (entry == null) return null;
        long remainingMs = entry.getRemainingMs();
        long totalSeconds = remainingMs / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format("%d:%02d", minutes, seconds);
    }

    public boolean clearTemporarySellBoost(Player target) {
        return temporarySellBoosts.remove(target.getUniqueId()) != null;
    }

    private long parseDurationString(String s) {
        if (s == null || s.isEmpty()) return -1;
        s = s.toLowerCase().trim();
        try {
            if (s.endsWith("ms")) {
                return Long.parseLong(s.substring(0, s.length()-2));
            } else if (s.endsWith("s")) {
                return Long.parseLong(s.substring(0, s.length()-1)) * 1000L;
            } else if (s.endsWith("m")) {
                return Long.parseLong(s.substring(0, s.length()-1)) * 60L * 1000L;
            } else if (s.endsWith("h")) {
                return Long.parseLong(s.substring(0, s.length()-1)) * 3600L * 1000L;
            } else {
                // default minutes
                return Long.parseLong(s) * 60L * 1000L;
            }
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void applyTemporarySellBoost(Player admin, Player target, double percent, long durationMs) {
        UUID uid = target.getUniqueId();
        long expiresAt = System.currentTimeMillis() + durationMs;
        BoostEntry entry = new BoostEntry(percent, expiresAt);
        temporarySellBoosts.put(uid, entry);

        long ticks = Math.max(1, durationMs / 50L);
        new BukkitRunnable() {
            @Override
            public void run() {
                BoostEntry current = temporarySellBoosts.get(uid);
                if (current != null && current.expiresAtMs <= System.currentTimeMillis()) {
                    temporarySellBoosts.remove(uid);
                    if (target.isOnline()) {
                        target.sendMessage("§eYour temporary sell boost has expired.");
                    }
                }
            }
        }.runTaskLater(this, ticks);

        admin.sendMessage(String.format("§aGiven %s a +%.0f%% sell boost for %s.", target.getName(), percent, formatDurationForMessage(durationMs)));
        if (target.isOnline()) {
            target.sendMessage(String.format("§aYou received a +%.0f%% sell boost from %s for %s.", percent, admin.getName(), formatDurationForMessage(durationMs)));
        }
    }

    private String formatDurationForMessage(long durationMs) {
        long seconds = durationMs / 1000L;
        if (seconds < 60) return seconds + "s";
        long minutes = seconds / 60;
        if (minutes < 60) return minutes + "m";
        long hours = minutes / 60;
        return hours + "h";
    }

    /**
     * Gets crop bonus value from rank in config (allows per-rank customization)
     */
    private int getCropBonus(Player player) {
        Integer rank = playerRanks.get(player.getUniqueId().toString());
        if (rank == null || rank <= 0) return 0;
        
        org.bukkit.configuration.ConfigurationSection ranksSection = getConfig().getConfigurationSection("ranks");
        if (ranksSection == null) return 0;
        
        org.bukkit.configuration.ConfigurationSection rankSection = ranksSection.getConfigurationSection(String.valueOf(rank));
        if (rankSection == null) return 0;
        
        return rankSection.getInt("crop-bonus", 0);
    }

    /* -------------------- CONFIG -------------------- */

    public Integer getPlayerRank(Player player) {
        return playerRanks.get(player.getUniqueId().toString());
    }

    public ConcurrentHashMap<Integer, Rank> getRankConfigs() {
        return rankConfigs;
    }

    /**
     * Check if a player has enough money for a purchase
     * Uses Vault if available, otherwise returns true (trusting the economy plugin)
     */
    private boolean hasPlayerEnoughMoney(Player player, double amount) {
        if (vaultEconomy != null) {
            return vaultEconomy.has(player, amount);
        }
        // If Vault not available, we can't verify - return true and hope the economy plugin is correct
        getLogger().warning("§eWarning: Cannot verify player balance without Vault. Trusting economy command for " + player.getName());
        return true;
    }

    /**
     * Format a currency value with comma separators
     * Example: 1000.50 -> "1,000.50"
     */
    public String formatCurrency(double amount) {
        return String.format("%,.2f", amount);
    }

    /**
     * Execute an economy command to deduct money from a player
     * ONLY used for rank purchases
     */
    private boolean takePlayerMoney(Player player, double amount) {
        // Prefer Vault if available for reliable transactions
        if (vaultEconomy != null) {
            net.milkbowl.vault.economy.EconomyResponse response = vaultEconomy.withdrawPlayer(player, amount);
            if (response.transactionSuccess()) {
                getLogger().info(String.format("Charged %s $%.2f for rank purchase (via Vault)", player.getName(), amount));
                return true;
            } else {
                getLogger().warning(String.format("Vault transaction failed for %s: %s", player.getName(), response.errorMessage));
                return false;
            }
        }
        
        // Fallback to command-based economy
        String command = ecoTakeCommand
                .replace("%player%", player.getName())
                .replace("%amount%", String.format("%.2f", amount));
        boolean result = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
        
        if (result) {
            getLogger().info(String.format("Charged %s $%.2f for rank purchase. Command: %s", player.getName(), amount, command));
        } else {
            getLogger().warning(String.format("Failed to charge %s $%.2f - command did not execute. Command: %s", player.getName(), amount, command));
        }
        return result;
    }

    /**
     * Execute an economy command to give money to a player
     */
    private boolean givePlayerMoney(Player player, double amount) {
        // Prefer Vault if available for reliable transactions
        if (vaultEconomy != null) {
            net.milkbowl.vault.economy.EconomyResponse response = vaultEconomy.depositPlayer(player, amount);
            if (response.transactionSuccess()) {
                getLogger().info(String.format("Gave %s $%.2f from Herb sale (via Vault)", player.getName(), amount));
                return true;
            } else {
                getLogger().warning(String.format("Vault transaction failed for %s: %s", player.getName(), response.errorMessage));
                return false;
            }
        }
        
        // Fallback to command-based economy
        String command = ecoGiveCommand
                .replace("%player%", player.getName())
                .replace("%amount%", String.format("%.2f", amount));
        boolean result = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
        
        if (result) {
            getLogger().info(String.format("Gave %s $%.2f from Herb sale. Command: %s", player.getName(), amount, command));
        } else {
            getLogger().warning(String.format("Failed to give %s $%.2f from Herb sale. Command: %s", player.getName(), amount, command));
        }
        return result;
    }

}







