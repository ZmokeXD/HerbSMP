package com.zmokesmp.zmokesmps4;

/**
 * Represents a purchasable rank.  Used by both the plugin core and GUI code.
 */
public class Rank {
    private final int number;
    private final String name;
    private final double price;
    private final double sellBoost;
    private final double dropBoost;

    public Rank(int number, String name, double price, double sellBoost, double dropBoost) {
        this.number = number;
        this.name = name;
        this.price = price;
        this.sellBoost = sellBoost;
        this.dropBoost = dropBoost;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getSellBoost() {
        return sellBoost;
    }

    public double getDropBoost() {
        return dropBoost;
    }
}

