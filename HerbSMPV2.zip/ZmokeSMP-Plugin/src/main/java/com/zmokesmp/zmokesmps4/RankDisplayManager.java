package com.zmokesmp.zmokesmps4;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class RankDisplayManager {
    private final Plugin plugin;
    private Object luckPerms;  // Use Object instead of LuckPerms to avoid hard dependency
    private boolean isLuckPermsAvailable = false;
    private int actionBarTaskId = -1;  // Store task ID for cancellation

    public RankDisplayManager(Plugin plugin) {
        this.plugin = plugin;
        
        // Try to load LuckPerms using reflection to avoid NoClassDefFoundError
        try {
            Class<?> luckPermsClass = Class.forName("net.luckperms.api.LuckPerms");
            this.luckPerms = Bukkit.getServicesManager().getRegistration(luckPermsClass);
            if (this.luckPerms != null) {
                // Extract the provider object
                this.luckPerms = this.luckPerms.getClass().getMethod("getProvider").invoke(this.luckPerms);
                isLuckPermsAvailable = true;
                plugin.getLogger().info("LuckPerms found and integrated!");
            } else {
                plugin.getLogger().warning("LuckPerms not found! Rank suffixes will not be set.");
            }
        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("LuckPerms plugin not installed. Rank suffixes will not be displayed.");
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to hook into LuckPerms: " + e.getMessage());
        }
    }

    /**
     * Update a player's rank display via LuckPerms
     */
    public void updatePlayerRankDisplay(Player player, Rank rank) {
        // Update LuckPerms suffix (async to avoid blocking)
        if (isLuckPermsAvailable && luckPerms != null) {
            updateLuckPermsSuffix(player, rank);
        }
    }

    /**
     * Update the player's suffix in LuckPerms using reflection
     * This sets the chat suffix that will display as [rank] after player names
     */
    private void updateLuckPermsSuffix(Player player, Rank rank) {
        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    // Get UserManager via reflection
                    Object userManager = luckPerms.getClass().getMethod("getUserManager").invoke(luckPerms);
                    Object userLoadFuture = userManager.getClass().getMethod("loadUser", java.util.UUID.class).invoke(userManager, player.getUniqueId());
                    Object user = userLoadFuture.getClass().getMethod("join").invoke(userLoadFuture);
                    
                    if (user == null) return;

                    // Get user data
                    Object userData = user.getClass().getMethod("data").invoke(user);

                    // Create suffix node via reflection - SuffixNode.builder() is static
                    Class<?> suffixNodeClass = Class.forName("net.luckperms.api.node.types.SuffixNode");
                    java.lang.reflect.Method builderMethod = suffixNodeClass.getDeclaredMethod("builder", String.class, int.class);
                    Object suffixBuilder = builderMethod.invoke(null, " §6[§e" + rank.getName() + "§6]§r", 100);
                    Object suffixNode = suffixBuilder.getClass().getMethod("build").invoke(suffixBuilder);
                    
                    // Add new suffix
                    userData.getClass().getMethod("add", Object.class).invoke(userData, suffixNode);

                    // Save user
                    userManager.getClass().getMethod("saveUser", Object.class).invoke(userManager, user);
                    
                    plugin.getLogger().info("§aUpdated LuckPerms suffix for " + player.getName() + " to rank: " + rank.getName());
                } catch (Exception e) {
                    plugin.getLogger().warning("Error updating LuckPerms for " + player.getName() + ": " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    /**
     * Setup a global broadcast scoreboard for all players to see rank changes
     */
    public void broadcastRankUp(Player player, Rank rank) {
        String message = "§6§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "§e" + player.getName() + " §ahas reached §e" + rank.getName() + " §7(Rank " + rank.getNumber() + ")§r\n" +
                        "§6§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
        
        Bukkit.broadcastMessage(message);
    }

    /**
     * Initialize scoreboard for a player when they join
     */
    public void initializePlayerScoreboard(Player player) {
        Integer rankNum = plugin.getPlayerRank(player);
        if (rankNum != null) {
            Rank rank = plugin.getRankConfigs().get(rankNum);
            if (rank != null) {
                updatePlayerRankDisplay(player, rank);
            }
        }
    }

    /**
     * Update action bar display for a single player
     */
    private void sendActionBar(Player player) {
        Integer rankNum = plugin.getPlayerRank(player);
        if (rankNum != null) {
            Rank rank = plugin.getRankConfigs().get(rankNum);
            if (rank == null) return;
            
            // Get crop bonus from config
            int cropBonus = 0;
            org.bukkit.configuration.ConfigurationSection ranksSection = plugin.getConfig().getConfigurationSection("ranks");
            if (ranksSection != null) {
                org.bukkit.configuration.ConfigurationSection rankSection = ranksSection.getConfigurationSection(String.valueOf(rankNum));
                if (rankSection != null) {
                    cropBonus = rankSection.getInt("crop-bonus", 0);
                }
            }
            
            // Determine whether to show action bar and get format from config
            boolean showActionBar = plugin.getConfig().getBoolean("display.show-action-bar", true);
            if (!showActionBar) {
                return;
            }
            String format = plugin.getConfig().getString("display.action-bar-format",
                "§6ʀᴀɴᴋ§7: §e{rank_name} §7| §6sᴇʟʟ§7: §a+{sell_boost}% §7| §6ᴅʀᴏᴘ§7: §a×{drop_boost} §7| §6ᴅʀᴏᴘ§7: §a+{crop_bonus}");
            
            // Replace placeholders
            String actionBarText = format
                .replace("{rank_name}", rank.getName())
                .replace("{rank_level}", String.valueOf(rankNum))
                .replace("{sell_boost}", String.valueOf((int) rank.getSellBoost()))
                .replace("{drop_boost}", String.format("%.1f", rank.getDropBoost()))
                .replace("{crop_bonus}", String.valueOf(cropBonus));

            double tempBoost = plugin.getTemporarySellBoostPercent(player.getUniqueId());
            String boostTime = plugin.getTemporarySellBoostTimeLeft(player.getUniqueId());
            String boostInfo = "";
            if (tempBoost > 0 && boostTime != null) {
                boostInfo = String.format("§6Boost§7: §a+%.0f%% §7(%s)", tempBoost, boostTime);
            }

            actionBarText = actionBarText
                .replace("{boost_amount}", tempBoost > 0 ? String.format("+%.0f%%", tempBoost) : "")
                .replace("{boost_time}", boostTime != null ? boostTime : "")
                .replace("{boost_info}", boostInfo);

            if (tempBoost > 0 && !format.contains("{boost_info}") && !format.contains("{boost_amount}") && !format.contains("{boost_time}")) {
                if (!actionBarText.isEmpty()) {
                    actionBarText += " §7| ";
                }
                actionBarText += boostInfo;
            }

            // Use Spigot component API for action bar
            net.md_5.bungee.api.chat.TextComponent component = new net.md_5.bungee.api.chat.TextComponent(actionBarText);
            player.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR, component);
        }
    }

    /**
     * Start a timer task to update action bars for all online players
     */
    public void startActionBarUpdateTask() {
        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    sendActionBar(player);
                }
            }
        };
        actionBarTaskId = task.runTaskTimer(plugin, 0L, 20L).getTaskId(); // Update every 20 ticks (1 second)
    }

    /**
     * Stop the action bar update task
     */
    public void stopActionBarTask() {
        if (actionBarTaskId != -1) {
            Bukkit.getScheduler().cancelTask(actionBarTaskId);
        }
    }
}


