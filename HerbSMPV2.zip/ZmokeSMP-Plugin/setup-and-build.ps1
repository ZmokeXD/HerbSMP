# Comprehensive Maven setup and build script for WeedSMP
# This script:
# 1. Searches for Maven installations
# 2. Adds Maven to PATH
# 3. Generates Maven wrapper
# 4. Builds the project

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "      WeedSMP Maven Setup & Build Script" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Try to find Maven on PATH
Write-Host "[1/5] Checking for Maven..." -ForegroundColor Yellow
$mvnCmd = Get-Command mvn -ErrorAction SilentlyContinue
if ($mvnCmd) {
    Write-Host "[OK] Maven found on PATH: $($mvnCmd.Source)" -ForegroundColor Green
    $mavenPath = Split-Path -Parent $mvnCmd.Source | Split-Path -Parent
} else {
    Write-Host "[SEARCH] Maven not found on PATH, searching system..." -ForegroundColor Yellow
    
    # Search common Maven install locations
    $searchPaths = @(
        "C:\Program Files\apache-maven*",
        "C:\Program Files (x86)\apache-maven*",
        "C:\maven*",
        "C:\tools\maven*",
        "$env:USERPROFILE\tools\maven*",
        "$env:USERPROFILE\apache-maven*"
    )
    
    $mavenPath = $null
    foreach ($pattern in $searchPaths) {
        $found = Get-Item $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            $mavenPath = $found.FullName
            Write-Host "✓ Found Maven at: $mavenPath" -ForegroundColor Green
            break
        }
    }
    
    if (-not $mavenPath) {
        Write-Host "✗ Maven not found on system!" -ForegroundColor Red
        Write-Host ""
        Write-Host "Please download Maven from: https://maven.apache.org/download.cgi" -ForegroundColor Cyan
        Write-Host "Extract it and set MAVEN_HOME to the folder path, then run this script again." -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Quick fix for current session:" -ForegroundColor Yellow
        Write-Host "`$env:MAVEN_HOME = 'C:\Extracted\Maven\Path'" -ForegroundColor Gray
        Write-Host "`$env:Path += ';' + `$env:MAVEN_HOME + '\bin'" -ForegroundColor Gray
        exit 1
    }
}

# Step 2: Set up PATH for this session
Write-Host ""
Write-Host "[2/5] Setting up PATH..." -ForegroundColor Yellow
$mvnBin = Join-Path $mavenPath "bin"
if (-not ($env:Path -contains $mvnBin)) {
    $env:Path = "$mvnBin;$env:Path"
    Write-Host "✓ Added Maven to PATH for this session" -ForegroundColor Green
}

# Step 3: Verify Maven works
Write-Host ""
Write-Host "[3/5] Verifying Maven..." -ForegroundColor Yellow
try {
    $mvnVersion = & mvn -v 2>&1 | Select-Object -First 1
    Write-Host "✓ $mvnVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Maven command failed: $_" -ForegroundColor Red
    exit 1
}

# Step 4: Generate Maven wrapper
Write-Host ""
Write-Host "[4/5] Generating Maven wrapper..." -ForegroundColor Yellow
Push-Location $projectRoot
try {
    & mvn -N "io.takari:maven:wrapper:wrapper" 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Maven wrapper generated (mvnw.cmd, .mvn/wrapper/)" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠ Wrapper generation had issues, continuing with build..." -ForegroundColor Yellow
}

# Step 5: Build the project
Write-Host ""
Write-Host "[5/5] Building WeedSMP plugin JAR..." -ForegroundColor Yellow
Write-Host "Running: mvn clean package -DskipTests=true" -ForegroundColor Gray
Write-Host ""

# Remove any old packaged JAR files before building
Get-ChildItem "$projectRoot\target\*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

try {
    & mvn clean package -DskipTests=true
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
        Write-Host "║                    ✓ BUILD SUCCESSFUL                      ║" -ForegroundColor Green
        Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green
        Write-Host ""

        # Remove any older JARs and keep only the newest packaged JAR
        $jarFiles = Get-ChildItem "$projectRoot\target\*.jar" -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike "*sources*" } | Sort-Object LastWriteTime -Descending
        if ($jarFiles.Count -gt 1) {
            $jarFiles | Select-Object -Skip 1 | Remove-Item -Force -ErrorAction SilentlyContinue
        }
        
        # Find and copy JAR
        $jarFile = Get-ChildItem "$projectRoot\target\*.jar" -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike "*sources*" } | Select-Object -First 1
        if ($jarFile) {
            Write-Host "JAR file: $($jarFile.Name)" -ForegroundColor Cyan
            Write-Host "Location: $($jarFile.FullName)" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "Next steps:" -ForegroundColor Yellow
            Write-Host "  1. Copy the JAR to your Minecraft server's plugins/ folder" -ForegroundColor White
            Write-Host "  2. Restart your server or use /reload" -ForegroundColor White
            Write-Host ""
            Write-Host "Required server plugins:" -ForegroundColor Yellow
            Write-Host "  - PlaceholderAPI" -ForegroundColor White
            Write-Host "  - LuckPerms" -ForegroundColor White
            Write-Host "  - Economy plugin (Vault, EssentialsX, etc.)" -ForegroundColor White
        }
    } else {
        Write-Host ""
        Write-Host "✗ Build failed (exit code: $LASTEXITCODE)" -ForegroundColor Red
        Write-Host "Check the error messages above." -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "✗ Build error: $_" -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}

Write-Host ""
Write-Host "Script completed." -ForegroundColor Cyan
